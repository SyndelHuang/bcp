function loadtx(blockhash, start) {
    $.getJSON("http://api.qukuai.com:8000/blocktx/" + $("#block_url").text() + "&start=" + start + "&callback=?",function(blocktx){
        if(start > 0){$("#more").remove()}
        for(var i in blocktx) {
            var tx_head = '<div class="tx-hash"><div class="hash-left"><a href="'+coin_url+'/tx/' + blocktx[i]["id"] + '">' + blocktx[i]["id"]
                + '</a></div><div class="tx-time hidden-xs">' + blocktx[i]["r"] + '</div></div>';
            var tx_html = $('<div class="tx-boxs"></div>').append(tx_head);
            var tx_info_row = $('<div class="addr-addrs"></div>');

            var tx_vi_info = $('<div class="addrs-left"></div>');
            var tx_vi_top5 = $('<div class="center-l"></div>');
            var tx_vi_more = $('<div class="tx-mord-box"></div>');
            var x = 0;
            if (blocktx[i].cb) {
                tx_vi_top5.append('<div class="tx-addr">'+l('BlockReward')+'</div>');
            }
            else{

                for(var j in blocktx[i].vi) {
                    var tx_vi = "";
                    for(var k in blocktx[i].vi[j].a) {
                        var tx_span_vi_a = '<div class="tx-addr"><div class="subaddr-p"><a href="'+coin_url+'/address/' + blocktx[i].vi[j].a[k] + '">' + blocktx[i].vi[j].a[k] + '</a></div></div>';
                        tx_vi = tx_vi + tx_span_vi_a;
                        var tx_val = '<div class="tx-num">' +getbtcvalue(blocktx[i].vi[j].v) +' ' +coin_unit +'</div>';
                        tx_vi = tx_vi + tx_val;
                    }

                    if(x < 5){
                        tx_vi_top5.append(tx_vi);
                    }else{
                        tx_vi_more.append(tx_vi);
                    }
                    x++;
                }
            }
            var tx_vi_top5_wrap = $('<div class="left-top"></div>');
            tx_vi_top5_wrap.append(tx_vi_top5);
            tx_vi_info.append(tx_vi_top5_wrap);
            if(x > 5){
                tx_vi_info.append(tx_vi_more);
                tx_vi_info.append('<div class="more-box"><div class="tx-addr"><a href="javascript:;" class="tx-more">'+l('More')+'</a></div></div>');
            }
            tx_info_row.append(tx_vi_info);
						$('<div class="addrs-img"><img src="/static/images/tx_jt.png"></div>').appendTo(tx_info_row);
            var tx_vo_info = $('<div class="addrs-right"></div>');
            var tx_vo_top5 = $('<div class="center-r"></div>');
            var tx_vo_more = $('<div class="tx-mord-box"></div>');
            x = 0
            for(var j in blocktx[i].vo) {
                var tx_vo = "";
                for(var k in blocktx[i].vo[j].a) {
                    var tx_span_vo_a = '<div class="tx-addr"><div class="subaddr-p"><a href="'+coin_url+'/address/' + blocktx[i].vo[j].a[k] + '">' + blocktx[i].vo[j].a[k] + '</a></div></div>';
                    tx_vo = tx_vo + tx_span_vo_a;
                    var tx_val = '<div class="tx-num in fwb">' +getbtcvalue(blocktx[i].vo[j].v) +' ' +coin_unit +'</div>';
                    tx_vo = tx_vo + tx_val;
                }

                if(x < 5){
                    tx_vo_top5.append(tx_vo);
                }else{
                    tx_vo_more.append(tx_vo);
                }
                x++;
            }
            var tx_vo_top5_wrap = $('<div class="right-top"></div>');
            tx_vo_top5_wrap.append(tx_vo_top5);
            tx_vo_info.append(tx_vo_top5_wrap);
            if(x > 5){
                tx_vo_info.append(tx_vo_more);
                tx_vo_info.append('<div class="more-box"><div class="tx-addr"><a href="javascript:;" class="tx-more">'+l('More')+'</a></div></div>');
            }
            tx_info_row.append(tx_vo_info);

            var addr_wrap = $('<div class="addr-box"></div>').append(tx_info_row);
						addr_wrap.append('<div class="tx-time-p visible-xs">' + blocktx[i]["r"] + '</div>')
            tx_html.append(addr_wrap);
            var tx_wrap = $('<div class="addrs mt20"></div>').append(tx_html);
            $("#block_tx").append(tx_wrap);
            $("#block_tx").append('<div class="clearfix"></div>');
        }
        if(blocktx.length == 25) {
            $("#block_tx").append('<a id="more" class="more-btn">'+l('Show_More')+'</a>');
            $("#more").click(function(){
                $("#more").text(l('Loading')+"...");
                start = start + 25;
                loadtx(blockhash, start);
            });
            $("#more").mouseover(function(){
              $("#more").css({"cursor":"pointer","background-color":"#eeeeee"});
            }).mouseout(function(){
              $("#more").css("background-color","#f9f9f9");
            });
        }
    }).done(function(){ adjustCSS(); });

}


function ch(){
	var width = $(window).width();
	if(width > 983){
		$(".center-l").each(function(){
        var numl = $(this).find('.tx-addr').length
        var lh = 0 - numl * 10 ;
        $(this).css("margin-top",lh);
				$(this).parent().css("height",100);
    });

    $(".center-r").each(function(){
        var numr = $(this).find('.tx-addr').length
        var rh = 0 - numr * 10 ;
        $(this).css("margin-top",rh);
				$(this).parent().css("height",100);
    });
	}else{
		$(".center-l").each(function(){
        var numl = $(this).find('.tx-addr').length
				$(this).css("margin-top",0);
        $(this).parent().css("height",numl*20);
    });
		$(".center-r").each(function(){
        var numr = $(this).find('.tx-addr').length
				$(this).css("margin-top",0);
        $(this).parent().css("height",numr*20);
    });
	}
}
function adjustCSS(){
    //adjust css
    ch();

    $(".tx-more").click(function(){
        var obj = $(this).parent().parent().parent().parent()
        var dis = obj.find(".tx-mord-box").css('display');
        if(dis == 'none'){
            obj.find(".tx-more").html(l('Put_Away'))
        }else{
            obj.find(".tx-more").html(l('More'))
        }
        obj.find(".tx-mord-box").slideToggle(200);
    })
}

$(document).ready(function(){
    $.getJSON("http://api.qukuai.com:8000/block/" + $("#block_url").text() + "&callback=?",function(data) {
        if(data.error && data.error==404) {
            if(data.tx) {
                top.location.href="/tx/"+data.tx;
                return;
            }
            else {
                $("#all").html('<div class="no-tx"><img src="/static/images/no_tx.png"><div class="no-title">'+l('No_Block_Found')+'</div><div class="no-tis">'+l('Can_Be_Later')+'<a href="javascript:location.reload();void(0);">'+l('Refresh')+'</a>'+l('Try_again')+'</div></div>');
                return;
            }
        }

        if($("#block_url").text().indexOf('ltc') >= 0) {
            coin_name = l('Ltc');
            coin_unit = 'LTC';
            coin_url = '/ltc';
            $('#block_info').addClass("tx-info mb22 tx-bgimg-ltc");
        }else{
            coin_name = l('Btc');
            coin_unit = 'BTC';
            coin_url = '';
            $('#block_info').addClass("tx-info mb22 tx-bgimg-btc");
        }

        var block_title = '<div class="all-title">'+l('Block')+'</div>';
        var block_link = $('<div class="next-block"></div>');
        if(data.previousblockhash !== undefined){
            block_link.append('<a href="'+coin_url+'/block/'+data.previousblockhash+'" id="link_prev_block">'+l('Prev')+'</a>');
        }
        block_link.append('<span id="block_height"></span>');
        if(data.nextblockhash !== undefined){
            block_link.append('<a href="'+coin_url+'/block/'+data.nextblockhash+'" id="link_next_block">'+l('Next')+'</a>');
        }
        $("#all div.all-title-box").append(block_title);
        $("#all div.all-title-box").append(block_link);

		// var blk_tb = $("<div class='col-md-8'></div>");
		// $("#block_info").append(blk_tb);
        // blk_tb.append('<h3 style="margin-top:5px;">'+coin_name+'区块</h3>');
        $('#block_height').text(data.height);
        // $('#link_prev_block').attr("href",coin_url+"/block/"+data.previousblockhash);
        // $('#link_next_block').attr("href",coin_url+"/block/"+data.nextblockhash);
        if(data.confirmations && data.confirmations==-1) {
            $("#block_info").append("<div class='info-left'>"+l('Height')+"</div><div class='info-right fwb'>" + data.height + "<span class='kuo'>（"+l('Orphaned_Blocks')+"）</span></div>" );
        } else {
            $("#block_info").append("<div class='info-left'>"+l('Height')+"</div><div class='info-right fwb'>" + data.height + "<span class='kuo'>（"+l('Main_Chain')+"）</span></div>" );
        }
        $("#block_info").append("<div class='info-left'>"+l('Num_Of_Tx')+"</div><div class='info-right'>" + data.count + "</div>" );

        $("#block_info").append("<div class='info-left'>"+l('Difficulty')+"</div><div class='info-right'>" + data.difficulty + "</div>" );
        $("#block_info").append("<div class='info-left'>"+l('Nonce')+"</div><div class='info-right'>" + data.nonce + "</div>" );
        $("#block_info").append("<div class='info-left'>"+l('Hash')+"</div><div class='info-right ddd '>" + data.hash + "</div>" );
        /* if(data.height==0) {
            $("#block_info").append("<div class='row table-row'><div class='col-md-3 resp-col'>上一区块</div><div class='col-md-9 resp-text-hash resp-col'>0000000000000000000000000000000000000000000000000000000000000000</div></div>" );
        } else {
            $("#block_info").append("<div class='row table-row'><div class='col-md-3 resp-col'>上一区块</div><div class='col-md-9 resp-text-hash resp-col'><a href='"+coin_url+"/block/"+data.previousblockhash+"'>" + data.previousblockhash + "</a></div></div>" );
        }
        if(data.nextblockhash){
            $("#block_info").append("<div class='row table-row'><div class='col-md-3 resp-col'>下一区块</div><div class='col-md-9 resp-text-hash resp-col'><a href='"+coin_url+"/block/"+data.nextblockhash+"'>" + data.nextblockhash + "</a></div></div>" );
        }
        else{
            if(data.confirmations && data.confirmations==-1) {
                $("#block_info").append("<div class='row table-row'><div class='col-md-3 resp-col'>下一区块</div><div class='col-md-9 resp-col'>暂无，当前区块已孤立</div></div>" );
            } else {
                $("#block_info").append("<div class='row table-row'><div class='col-md-3 resp-col'>下一区块</div><div class='col-md-9 resp-col'>暂无，当前区块为最新</div></div>" );
            }
        } */
        $("#block_info").append("<div class='info-left'>"+l('Timestamp')+"</div><div class='info-right'>" + data.time + "</div>" );

        // $("#block_tx").append('<h3>包含的交易</3>');
        loadtx(data.hash, 0);
				$(window).resize(function() {
					ch()
				})

    });
    adjustCSS();
});


