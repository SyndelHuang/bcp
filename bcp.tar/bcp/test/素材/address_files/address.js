coin = $.trim($("#nowcoin").text().toLowerCase());
coin_flag = coin.toUpperCase() == "LTC";


function ch(){
	var width = $(window).width();
	if(width > 983){
		$(".center-l").each(function(){
        var numl = $(this).find('.tx-addr').length
        var lh = 0 - numl * 10 ;
        $(this).css("margin-top",lh);
				$(this).parent().css("height",100);
    });

    $(".center-r").each(function(){
        var numr = $(this).find('.tx-addr').length
        var rh = 0 - numr * 10 ;
        $(this).css("margin-top",rh);
				$(this).parent().css("height",100);
    });
	}else{
		$(".center-l").each(function(){
        var numl = $(this).find('.tx-addr').length
				$(this).css("margin-top",0);
        $(this).parent().css("height",numl*20);
    });
		$(".center-r").each(function(){
        var numr = $(this).find('.tx-addr').length
				$(this).css("margin-top",0);
        $(this).parent().css("height",numr*20);
    });
	}
}

function loadtx(obj)
{
	
	var tx_id = obj.parent().parent().parent().parent().parent().parent().find('.hash-left').find('a').html();
	var sign = obj.parent().parent().parent().parent().parent().parent().find("#sign").html();
	var tx_url;
	coin_flag ? (coin_name = "\u83b1\u7279\u5e01", coin_unit = "LTC", coin_url = "/ltc") : (coin_name = "\u6bd4\u7279\u5e01", coin_unit = "BTC", coin_url = "");
	if(coin_unit == "LTC")
	{
		tx_url = tx_id+"?ltc=1"+"&sign="+sign;
	}
	else{	
		tx_url = tx_id+"?sign="+sign;
	}
	var left_box = obj.parent().parent().parent().parent().parent().parent().find('.addrs-left');
	var right_box = obj.parent().parent().parent().parent().parent().parent().find('.addrs-right');
	var right_num = obj.parent().parent().parent().parent().parent().parent().find('.addrs-right').find(".addr-num").html();
	$.getJSON("http://api.qukuai.com:8000/tx/" + tx_url +"&callback=?", function (a) {
		var curr_addr = $("#addr").text();
		if (a.error && 404 == a.error)
			obj.text(l('Failed_Load'));
		else {
			
			
			

			var tx_span_vi = '';
			if (!("vi" in a)) {
				tx_span_vi = '<div class="tx-addr">'+l('Newly_Generated_Coins')+'</div>';
			}
			else{
				var tx_span_vi_a = "";
				var x = 0;
				var vin_a = "";
				for(var i in a.vi)
				{
					
					if (null == a.vi[i].a || 0 == a.vi[i].a.length)
						tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr out">'+l('Cannot_address')+'</div>';
					else if(1 == a.vi[i].a.length)
					{
						if( a.vi[i].a[0].indexOf(curr_addr) >= 0)
						{
							tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr">' + a.vi[i].a[0] + '</div>';
						}
						else
							tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr"><a href="' + coin_url+'/address/' + a.vi[i].a[0] + '">' + a.vi[i].a[0] + '</a></div>';
					}
					else if( 1 < a.vi[i].a.length)
					{
						//tx_span_vi_a = "[ ";
						for(var j in a.vi[i].a)
						{
							if(j == 0){
								svi = "[&nbsp;";
							}else{
								svi =""
							}
							if(j == (a.vi[i].a.length-1)){
								evi = "&nbsp;]";
							}else{
								evi =""
							}
							var addr = a.vi[i].a[j];
							if(vin_a.indexOf(addr)<0)
							{
								vin_a += a.vi[i].a[j];
								if(addr.indexOf(curr_addr) >= 0)
								{
									tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr"><a class="curr_addr">' +svi+ addr + evi+'</a></div>';
								}
								else
									tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr"><a href="' + coin_url+'/address/' + a.vi[i].a[j] + '">' + a.vi[i].a[j] + '</a></div>';
							}
						}
						//tx_span_vi_a += " ]";
					}
					x++;
				}
			}
			if(x > 4){
				left_box.html('<div class="left-top addr-left">'+tx_span_vi_a+'</div>')
			}
			var tx_span_vo_a = "";
			var x = 0;
			for(var i in a.vo)
			{	
				//console.log(a.vo[i])
				if (null == a.vo[i].a || 0 == a.vo[i].a.length){
					tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr out">'+l('Cannot_address')+'</div>';
				}else if(1 == a.vo[i].a.length)
				{
					if(a.vo[i].a[0].indexOf(curr_addr) >= 0 )
					{
						tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">' + a.vo[i].a[0] +'</div></div>';
					}else
						tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p"><a href="' +coin_url+'/address/' + a.vo[i].a[0] + '">' + a.vo[i].a[0] + '</a></div></div>';
				}
				else if(1 < a.vo[i].a.length)
				{
					//tx_span_vo_a = '<div style="float:left">[&nbsp;</div> ';
					for(var j in a.vo[i].a) {
						if(j == 0){
							svo = "[&nbsp;";
						}else{
							svo =""
						}
						if(j == (a.vo[i].a.length-1)){
							evo = "&nbsp;]";
						}else{
							evo =""
						}
						if(a.vo[i].a[j].indexOf(curr_addr) >= 0 )
						{
							tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">' + svo+a.vo[i].a[j] +evo+'</div></div>';
						}else
							tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">'+svo+'<a href="' +coin_url+'/address/' + a.vo[i].a[j] + '">' + a.vo[i].a[j] + '</a>'+evo+'</div></div>';
					}
					
					//tx_span_vo_a += " ]";
				}
				
				x++;
			}
			//console.log(x)
			if(x > 4){
				right_box.html('<div class="addr-num">' + right_num + '</div><div class="tx-mord-box addr-left show">'+tx_span_vo_a+'</div>')
			}
			
			
		}
	});
	obj.text(l('Loading')+"...");
}
function createtxlist(tx, coin_url, coin_unit)
{
	var curr_addr = $("#addr").text();
	for (b = tx.length - 1; 0 <= b; b--){
		value = getbtcvalue(tx[b].b);
		
	
		
		var addrs = '';
		addrs = '<div class="clearfix"></div><div class="addrs mt20">'
		addrs += '<div class="tx-boxs">'
		addrs += '<div class="tx-hash"><div class="hash-left"><a  href="'+coin_url+'/tx/' + tx[b].t + '">' + tx[b].t + '</a></div><div class="tx-time hidden-xs">' + tx[b].r + '</div>'
		if("sign" in tx[b])
		{
			addrs += '<div id="sign" class="hidden">' + tx[b].sign.toString() + '</div>';
		}
		addrs += '</div>'
		addrs += '<div class="addr-box">'
		if (tx[b].tg){
			for (var c = 0; c < tx[b].tg.length; c++){
				addrs += '<div class="remark">'+l('Notes')+' ('+l('By_Outputer')+')：' + tx[b].tg[c].tg +'</div>';
			}
		}
							
		addrs += '<div class="addr-addrs">'
		var arrow = "-" == value[0] ? "addr_jt.png" : "tx_jt.png";
		
		addrs += '<div class="addrs-left">'
		addrs += '<div class="left-top addr-left">'
		addrs += '<div class="center-l">'

		var tx_span_vi_a = ""
		var more_l = "";
		if (tx[b].vi.length == 0) {
			tx_span_vi_a = ('<div class="tx-addr">'+l('Newly_Generated_Coins')+'</div>');
		}
		else{
			var vii = 0;
			for(var j in tx[b].vi) {
				if (null == tx[b].vi[j].a || 0 == tx[b].vi[j].a.length){
					tx_span_vi_a += '<div class="tx-addr out">'+l('Cannot_address')+'</div>';
					
					vii++
				}else if(1 == tx[b].vi[j].a.length)
				{
					if(tx[b].vi[j].a[0].indexOf(curr_addr) >= 0)
					{
						tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr">' + tx[b].vi[j].a[0] + '</div>';
					}
					else
						tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr"><a href="' +coin_url+'/address/' + tx[b].vi[j].a[0] + '">' + tx[b].vi[j].a[0] + '</a></div>';
					vii++;
				}
				else if( 1 < tx[b].vi[j].a.length)
				{
					//tx_span_vi_a += '<div style="float:left">[&nbsp;</div>';
					for(var k in tx[b].vi[j].a) {
						if(k == 0){
							svi = "[&nbsp;";
						}else{
							svi =""
						}
						if(k == (tx[b].vi[j].a.length-1)){
							evi = "&nbsp;]";
						}else{
							evi =""
						}
						if(tx[b].vi[j].a[k].indexOf(curr_addr) >= 0)
						{
							tx_span_vi_a = tx_span_vi_a + '<div class="tx-addr">' +svi+ tx[b].vi[j].a[k] + evi +'</div>';
						}
						else
							tx_span_vi_a = tx_span_vi_a +  '<div class="tx-addr">'+svi+'<a href="' +coin_url+'/address/' + tx[b].vi[j].a[k] + '">' + tx[b].vi[j].a[k] + '</a>'+evi+'</div>';
							vii++;
							if(vii>4){
								break;
							}
					}	
					//tx_span_vi_a += '<div style="float:left">&nbsp;]</div>';
				}
				
				if(j == 4 || vii > 4)
				{	
					more_l = '<div class="tx-mord-box addr-left"></div>';
					more_l += '<div class="more-box addr-left"><div class="tx-addr"><a href="javascript:;" class="tx-more">'+l('More')+'</a></div></div>';
				}
				if(vii>4){
					break;
				}
				
			}
		}
		addrs += tx_span_vi_a
		addrs += '</div></div>' + more_l;

		addrs += '</div>'
		addrs += '<div class="addrs-img addr-img"><img src="/static/images/'+arrow+'" ></div>'
		addrs += '<div class="addrs-right addr-right">'
		var topx = ''
		if("cf" in tx[b]){
			if(tx[b].cf > 6){
				topx = 'topx'
			}
		}
		addrs += '<div class="addr-num '+topx+'">'
		addrs += "-" == value[0] ?  '<div class="fwb out">' + value + " " + coin_unit +'</div>' :  '<div class="fwb in">' + value + " " + coin_unit +'</div>';

		if("cf" in tx[b])
		{
			if(tx[b].cf < 6)
			{
				addrs += '<div class="ok"><img src="/static/images/tx_ok.png"> '+tx[b].cf+l('Confirmation')+'</div>';
			}			
		}
		else{
			addrs += '<div class="ok"><img src="/static/images/tx_alert.png"> '+l('Un_T')+'</div>';
		}
		addrs += '</div>'
		addrs += '<div class="right-top">'
		addrs += '<div class="center-r">'
		var tx_span_vo_a = '';
		var more_r = '';
		var voi = 0;
		for(var j in tx[b].vo) {	
			if (null == tx[b].vo[j].a || 0 == tx[b].vo[j].a.length){
				tx_span_vo_a += '<div class="tx-addr out">'+l('Cannot_address')+'</div>';
				voi++;
			}else if(tx[b].vo[j].a.length == 1)
			{
					if(tx[b].vo[j].a[0].indexOf(curr_addr) >= 0)
					{
						tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">'+ tx[b].vo[j].a[0] + '</div></div>';
					}
					else
						tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p"><a href="' +coin_url+'/address/' + tx[b].vo[j].a[0] + '">' + tx[b].vo[j].a[0] + '</a></div></div>';
						
					voi++;
			}
			else if(1 < tx[b].vo[j].a.length)
			{
				//tx_span_vo_a += '<div style="float:left">[&nbsp;</div>';
				for(var k in tx[b].vo[j].a) {
					if(k == 0){
						svo = "[&nbsp;";
					}else{
						svo =""
					}
					if(k == (tx[b].vo[j].a.length-1)){
						evo = "&nbsp;]";
					}else{
						evo =""
					}
					if(tx[b].vo[j].a[k].indexOf(curr_addr) >= 0)
					{
						tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">'+svo+ tx[b].vo[j].a[k] + evo+'</div></div>';
					}else
					tx_span_vo_a = tx_span_vo_a + '<div class="tx-addr"><div class="subaddr-p">'+ svo+'<a href="' +coin_url+'/address/' + tx[b].vo[j].a[k] + '">' + tx[b].vo[j].a[k] + '</a>'+evo+'</div></div>';
					voi++;
					if(voi>4){
						break;
					}
				}
				//tx_span_vo_a += '<div style="float:left">&nbsp;]</div>';
			}
			if(j == 4 || voi>4)
			{	
				more_r = '<div class="tx-mord-box addr-right"></div>';
				more_r += '<div class="more-box addr-left"><div class="tx-addr"><a href="javascript:;" class="tx-more">'+l('More')+'</a></div></div>';
			}
			if(voi>4){
				break;
			}
		}
		addrs += tx_span_vo_a
		addrs += '</div></div>' + more_r;
				//alert(tx_span_vo_a)
				addrs += '</div></div></div><div class="tx-time-p visible-xs">' + tx[b].r + '</div></div></div></div>'
		
		$("#all").append(addrs)
		
	}
	//$("#all").append('<div class="clearfix mb100"></div>')
		ch()
}
$(document).ready(function () {
	$.getJSON("http://api.qukuai.com:8000/address/" + $("#a_url").text() + "&callback=?", function (a) {
		if (a.error && 404 == a.error)
			$("#a_info").append("<p>\u672a\u67e5\u5230\u6b64\u5730\u5740\uff0c\u8bf7\u68c0\u67e5\u60a8\u641c\u7d22\u7684\u5730\u5740\u662f\u5426\u6b63\u786e\uff01</p>");
		else {
			coin_flag ? (coin_name = "\u83b1\u7279\u5e01", coin_unit = "LTC", coin_url = "/ltc") : (coin_name = "\u6bd4\u7279\u5e01", coin_unit = "BTC", coin_url = "");
			if(a.tg){
				$("#addr-title").html( a.tg )
			}
			$("#tx_info").append('<div class="info-left">'+l('Address')+'</div><div class="info-right fwb ddd" id="addr">' + a.id + '</div>');
			a.tg && a.tgs && (
						$("#tx_info").append('<div class="info-left">'+l('Tag')+'</div><div class="info-right"><a href="' + a.tgurl + '" target="_blank">'+  a.tg  +'</a>（'+l('Authenticated')+'<a href="javascript:;" id="sign_t">'+l('Sign')+'</a><img src="/static/images/tx_ok.png">）<div id="tgs">'+a.tgs+'</div></div>'));
						sign_sel = "#sign_t";
						tgs_sel = "#tgs";
						$(tgs_sel).hide();
						$(tgs_sel).css("line-height","14px")
						$(sign_sel).click(function(){
								$(tgs_sel).toggle();
						});
						$(sign_sel).mouseover(function(){
							$(sign_sel).css("cursor","pointer");
						})
			$("#tx_info").append('<div class="info-left">'+l('No._Transactions')+'</div><div class="info-right">' + a.c +'</div>');
			$("#tx_info").append('<div class="info-left">'+l('Total_Input')+'</div><div class="info-right">' + getbtcvalue(a.i) + " " + coin_unit +'</div>');		
			a.u && 0 != a.u ? $("#tx_info").append('<div class="info-left">'+l('Balance')+'</div><div class="info-right in fwb">' + getbtcvalue(a.b) + " " + coin_unit +' <span class="kuo">（'+l('Not_Included')+'）</span></div>'):$("#tx_info").append('<div class="info-left">'+l('Balance')+'</div><div class="info-right in fwb">' + getbtcvalue(a.b) + " " + coin_unit +'</div>');
			a.u && 0 != a.u && $("#tx_info").append('<div class="info-left">'+l('Unconfirmed')+'</div><div class="info-right yellow fwb"><div class="ok_num">' + getbtcvalue(a.u) + " " + coin_unit + '</div> <img src="/static/images/tx_alert.png" class="ok_img"></div>');
			if(a.rank){
				$("#tx_info").append('<div class="info-left">'+l('Balance_rank')+'</div><div class="info-right">' + a.rank + ' <span>'+l('Be_Located') + a.rankper +'%</span></div>');
			}
			$("#tx_info").append('<div class="qr" id="code"></div>');
			$("#code").qrcode({
			//render: "table",
			width: 150,
			height:150,
			text: a.id
			});
			
			//get remain data
			if (a.tu){
				createtxlist(a.tu, coin_url, coin_unit);
            }
			if (a.t){
				createtxlist(a.t, coin_url, coin_unit);
			}
			//console.log(a)
			
			if('t' in a){
				if(a.t.length >=5)
				{
					$.getJSON("http://api.qukuai.com:8000/address/" + $("#a_url").text() + "&txid="+$('.hash-left a').last().html()+"&remain=all&callback=?", function (a) {
						if (a.tu){
							createtxlist(a.tu, coin_url, coin_unit);
						}
						if (a.t){
							createtxlist(a.t, coin_url, coin_unit);
						}
						$("#all").append('<div class="clearfix mb100"></div>')
						$(".tx-more").click(function(){
							loadtx($(this))
						})
					});
				}else{
					$("#all").append('<div class="clearfix mb100"></div>')
					$(".tx-more").click(function(){
						loadtx($(this))
					})
				}
			}else{
				$(".tx-more").click(function(){
					loadtx($(this))
				})
			}
			
			$(window).resize(function() {
				ch()
			})
			
		}
	})
});
