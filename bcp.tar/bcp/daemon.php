<?php
/*
功能：
	常驻内存，实现 “虚拟币->MYSQL” 数据即时更新

启动进程：
	打开linux终端输入：
	nohup php /var/www/blockchainexplorer/daemon.php &  
	注意后面有个&符
	然后不要直接关闭终端，要回车回到命令行界面，再输入exit和回车来关闭终端
	注意不要启动多个nohup php

关闭进程：
	首先用 ps -e 查看所有进程，找到php的PID如917
	然后 kill 917

维护：
	欲关闭本机虚拟币RPC服务时，请注意本进程是否正在导入数据，方法是：
	浏览器访问本目录下cache/sleeping.txt并随时刷新，如果内容不是busy，而是1到60之间的数字，说明进程正在sleep，即可杀，数字越小表示等待下一次转数据的时间越长。
	如能在关闭前kill掉本进程最好，但不是必须的。
	
其它：
	为了能被php解释器执行，本文件开头的<?php不能简写成短标签模式<? 
*/

error_reporting(0);
set_time_limit(0);//无限运行时间
define('AUTOUPDATE',1);
$Daemon = new Daemon();
$Daemon->stopWebAccess();//禁止从APACHE或NGINX调用
$Daemon->run();


//本对象常驻内存，负责及时把BlockChain的信息更新进MYSQL
class Daemon{
	private static $Mysql;
	private static $RPC;
	private static $MBlockChain;
	private static $statusfile;
	function __construct(){
		self::$statusfile =__DIR__.'/cache/sleeping.txt';
		include_once('config/config.php');
		include_once('lib/Mysql.php');
		Db::init($db_config);
		include_once 'lib/jsonRPCClient.php';
		//需要php.in allow_url_fopen = On:
		self::$RPC = new jsonRPCClient("http://$rpcuser:$rpcpass@127.0.0.1:".PORT_COIN.'/');//写localhost会失败
		include_once('lib/BlockChainUpdater.php');
		self::$MBlockChain = new MBlockChain(
								self::$RPC,
								self::$Mysql
							);
	}
	
	function stopWebAccess(){
		if( array_key_exists('SERVER_NAME',$_SERVER) ){
			echo '<meta charset="utf-8">';
			echo '不许从WEB访问';
			die;
		}
	}
	
	//是否可通讯mysql
	private function isMysqlAlive(){
		$bool = Db::reconnect();
		return $bool;
	}
	//是否可通讯RPC
	private function isRPCAlive(){
		try{
			$blockcount = self::$RPC->getblockcount();
			$bool = (boolean) $blockcount;
		}catch(Exception $e){
			$bool = false;
		}
		return $bool;
	}
	//是否有别的程序在处理MYSQL和BLOCKCAIN的数据更新
	private function isBlocked(){
		$text = file_get_contents(
					__DIR__.'/config/DataAutoUpdate-pause.txt'
				);
		return ( $text=='pause' ) ? true : false;
	}
	
	/*为了进程的长期稳定性，每次更新数据前都要检查一下数据连接
		确保当人为关掉MYSQL或者RPC时，本程序还能继续运行
	*/
	function prepare(){
		do{
			sleep(3);//如果环境检查失败，就3秒后再检查一次
			$ok = $this->isMysqlAlive()
				&& $this->isRPCAlive() 
				&& !$this->isBlocked()
				&& !$this->isBusy();//避免万一有两个Daemon冲突
		}while(!$ok);
		return true;
	}
	function isBusy(){
		$text= file_get_contents(self::$statusfile);
		return ($text=='busy') ? true : false;
	}
	function iAmBusy(){
		file_put_contents(self::$statusfile,'busy');
	}
	//睡$seconds秒
	function iAmSleeping($seconds){
		for($i=1;$i<=$seconds;$i++){
			file_put_contents(self::$statusfile,$i);//在文件上计秒
			sleep(1);//睡1秒
		}
	}
	function run(){
		while(1){
			$this->prepare();
			$this->iAmBusy();
			self::$MBlockChain->heightGrowing();//增加区块数据到MYSQL
			//刷新两个余额统计表：
			$mTop = new MTop();
			$mTop->refresh();
			//进入睡眠状态六十秒：
			$this->iAmSleeping(60);
			
		}
	}
}
?>
