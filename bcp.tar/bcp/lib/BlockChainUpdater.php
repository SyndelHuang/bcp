<?php
/*
负责把区块链的数据更新到MYSQL中。
*/
class MBlockChain{
	public static $RPC;
	
	public function __construct($RPC){
		self::$RPC = $RPC;
	}//ok
	
	//让Mysql中的区块数据达到blockchain的实时高度-5
	public function heightGrowing(){
		$latest = 1;
		/*
		剩余$latest个最新区块不计入MYSQL，详情见中本聪论文第5节“网络”:	"如果有两个节点同时广播不同版本的新区块，那么其他节点在接收到该区块的时间上将存在先后差别。当此情形，他们将在率先收到的区块基础上进行工作，但也会保留另外一个链条，以防后者变成最长的链条。"
		*/
		$heightMysql =  Db::getGrid('SELECT blocks FROM info LIMIT 1');//MYSQL已达到的区块高度
		$heightChain  = self::$RPC->getblockcount();//区块链已达到的区块高度
		if( $heightMysql == $heightChain-$latest ){//最新的$latest个区块不处理
			return false;//不可以用die 因为本程序需要长期在linux后台服务
		}else{
			$h = $heightMysql+1;
			$i=0;
			while( $h <= $heightChain-$latest){ //-5是因为最新的5个块还不算完全确认，不能算入余额统计，否则一旦区块链分叉就不好回滚数据
				//if( $h!=23592 && $h!=25237 && $h!=25236) continue;
				$mBlock = new MBlock($h);
				$bool = $mBlock->save();//添加区块信息到MYSQL
				if($bool){//如果成功
					Db::query("UPDATE info SET blocks = $h ");//更新info表
				}else{//如果失败
					//$msg = $this->rollback($h);//撤销操作
					//bug:rollback以后必须记录一下错误，因为这个区块的数据没有被记录进MYSQL里
					//break;
				}
				$h++;
				
				
				//$i++;
				//中途睡眠
				//if($i % 100 ==0){
				//	echo $h,'<br>';
				//	sleep(1);
				//}
				//$ddd = 25237-23592;
				//if($i>6){
					//echo $h,'<br>';
					//die;
				//}
			}
		}
	}//ok

}

class MBlock{
	public $block;
	
	public function __construct($height){
		//获取区块信息:
		$this->block = MBlockChain::$RPC->getblockbynumber($height);
		//echo $this->block['height'];
		//print_r($this->block);die;
	}//ok
	
	public function save(){
		//bug:第0个区块的第0个交易读不出来，ECO币的雇主说那条交易啥也没有，跳过就行
		if($this->block['height']==0){return true;}
		$this->hookPreviousBlock();
		$output_amount = 0;
		if(count($this->block['tx'])>0){
			foreach($this->block['tx'] as $txid){
				$mTransaction = new MTransaction($txid,$this);
				$output_amount += $mTransaction->save();
			}
		}
		$bool = $this->saveBlock($output_amount);//由于需要记录'转出总额',故在$mTransaction完成之后才运行本句
		return $bool;
	}//ok
	
	//给前一块添加nextblockhash：
	private function hookPreviousBlock(){
		if($this->block['height']==0) return true;
		Db::query("
			UPDATE block 
			SET nextblockhash='".$this->block['hash']."' 
			WHERE height='".($this->block['height']-1)."' and nextblockhash='' 
		");
	}//ok
	
	//block表添加记录：
	private function saveBlock($output_amount){
		$bool = Db::query(
			"INSERT INTO block SET 
			  size=".$this->block['size'].",
			  height=".$this->block['height'].",
			  version=".$this->block['version'].",
			  merkleroot='".$this->block['merkleroot']."',
			  mint=".$this->block['mint'].",
			  time=".$this->block['time'].",
			  nonce=".$this->block['nonce'].",
			  bits='".$this->block['bits']."',
			  difficulty=".$this->block['difficulty'].",
			  flags='".$this->block['flags']."',
			  proofhash='".$this->block['proofhash']."',
			  entropybit=".$this->block['entropybit'].",
			  modifier='".$this->block['modifier']."',
			  num_tx=".count($this->block['tx']).",
			  output_amount=".$output_amount.",
			  hash ='".$this->block['hash']."',
			  previousblockhash='".$this->block['previousblockhash']."',
			  nextblockhash='".$this->block['nextblockhash']."'
		");
		return $bool;
	}//ok
	
}

class MTransaction{
	
	public $txdetail;
	public $mBlock;
	public $tid;//tx表里的记录id
	
	public function __construct($txid,$mBlock){
		$this->txdetail = MBlockChain::$RPC->gettransaction($txid);
		$this->mBlock = $mBlock;
	}//ok
	
	//总的数据保存过程：
	public function save(){
		//以下语句次序不可更改：
		$this->tid = $this->saveTx();
		$input_amount = $this->saveVin();//逻辑上应该是先取款后付款，所以vin的处理在先，防止余额统计出问题
		$output_amount = $this->saveVout();
		$this->saveFee($input_amount,$output_amount);//记录本交易支付的矿工费
		return $output_amount;
	}//ok
	
	//交易表增加本交易记录：
	public function saveTx(){
		$SQL_COINBASE = '';
		if( array_key_exists('coinbase',$this->txdetail['vin'][0]) ){
			//证明是旷工奖励型的交易
			$cb = $this->txdetail['vin'][0]['coinbase'];
			$SQL_COINBASE = ", coinbase='$cb' ";//那么就要记录旷工留言
		}
		Db::query(
			"INSERT INTO tx SET 
				txid='".$this->txdetail['txid']."',
				height=".$this->mBlock->block['height'].",
				version=".$this->txdetail['version'].",
				txtime=".$this->txdetail['time'].",
				locktime=".$this->txdetail['locktime'].",
				fee=0,
				output_amount=0 
				$SQL_COINBASE 
		");
		return Db::insert_id();
	}//ok
	
	//计算本交易支付的矿工费并保存：
	public function saveFee($input_amount,$output_amount){
		$FEE = '';
		if( array_key_exists('fee',$this->txdetail) ){//一旦fee存在就不太可能等于零了所以不做零的判断
			$fee = floatval( $this->txdetail['fee'] );
			if($fee<0) $fee = $fee * -1;//变成正数
			$fee = $fee * 100000000;//单位变成聪
			$FEE = ' fee='.$fee.',';
		}else{//否则就尝试自己计算fee(不过计算出来很可能就是0)：
			if($input_amount > 0){
				$fee = $input_amount - $output_amount;
				if($fee>0){
					$FEE = ' fee='.$fee.',';
				}
				//echo $this->txdetail['txid'],' ',$input_amount,' ', $output_amount,'<br>';
			}else{
				//证明是奖励旷工型的交易,本交易支付的旷工费fee为零，不做任何操作
				//逻辑上即使无法证明是旷工型的交易，反正input_amount=0也不可能支付fee了
			}
		}//ok,经少数交易的测试，以上两个fee的计算方式都得到同样的结果
		
		Db::query('
			 UPDATE tx SET 
				'.$FEE.'
				output_amount = '.$output_amount.'
			 WHERE id='.$this->tid.'
		');
	}//ok
	
	//所有输入点的保存：
	private function saveVin(){
		$input_amount =0;
		if( count($this->txdetail['vin'])>0 ){
			foreach($this->txdetail['vin'] as $in){
				$input_amount += MTxInput::save($in,$this);
			}
		}
		return $input_amount;
	}//ok
	
	//所有输出点的保存：
	private function saveVout(){
		$output_amount = 0;
		if( count($this->txdetail['vout'])>0 ){
			foreach($this->txdetail['vout'] as $out){
				//bug:也许这里不应该用continue，我只是不理解value=0的交易何必存在，但既然存在必然有理由，我不应该自作主张地不记录它
				if($out['value'] == 0) continue;//见txid = a051a3c6c16bfec3836b0984bb35c6fac6b97189a1f53b5f14fd132f3d9be9b0
				MTxOutput::save($out,$this);
				$output_amount += $out['value'] * 100000000;
			}
		}
		return $output_amount;
	}//ok
	
	
}

class MTxInput{
	
	public static function save(&$in,$mTransaction){
		$where_vout = self::getWhereVout($in);
		if($where_vout){
			//获取本输入所引用的输出口：
			$vout = Db::getRow("
				SELECT * FROM tx_vout WHERE $where_vout 
			");
			//把那个输出口标记为已花费：
			Db::query('
				UPDATE tx_vout SET 
						spentbytid='.$mTransaction->tid.'
				WHERE '.$where_vout.' 
			');
			if($vout['address'] != 'unrecognize'){
				MAddress::save( 'addr_in_inputpoint',
							$vout['address'],
							$vout['value'],
							$mTransaction);
			}
			return $vout['value'];
		}else{
			return 0;//找不到$where_vout,没有输入口,没有金额来源，故返回金额0
			//可能是矿工奖励型的交易
		}
		
	}//ok
	
	//获取SQL的WHERE语句，以便找到本输入所引用的输出口
	private static function getWhereVout(&$in){
		if( array_key_exists('coinbase',$in)){
			return false;//矿工奖励型的交易,没有输入口
		}
		if( array_key_exists('txid',$in) && array_key_exists('vout',$in) ){
			$from_tid = Db::getGrid(
				"SELECT id FROM tx WHERE txid='".$in['txid']."'"
			);
			if($from_tid){
				$where_vout = ' tid='.$from_tid.' AND n='.$in['vout'].' ';
				return $where_vout;
			}
		}
		return false;
	}//ok
}

class MTxOutput{
	
	public static function save(&$out,$mTransaction){
		/*
		bug:(在本币中应该不算bug了)这里只有一个case，另一种case没有考虑到，
			也就是多重签名交易的情况，必须考虑这种交易里面的vout下的address与P2PKH交易的区别。
			每个vout的addresses是个数组一直迷惑我，我猜想，应该是用于填写多重签名时的多个公钥
			
			不过这个eco币去掉了createmultisig接口，似乎是不允许创建多重签名交易了，所以我也测试不了，就不做了。
		
		$out['scriptPubKey']['type']有6种，
			参考：https://bitcoin.org/en/developer-reference#decoderawtransaction
			我并没有完全考虑这六种情况，因为不是用比特币在做测试，很难找到例子
			• pubkey： for a P2PK script
			• pubkeyhash： for a P2PKH script
			• scripthash： for a P2SH script
			• multisig： for a bare multisig script
			• nulldata： for nulldata scripts
			• nonstandard： for unknown scripts
		*/
		
		$value = $out['value']*100000000;	
		if( $value>0 ){
			$addr = self::getAddr($out['scriptPubKey']);
			//既然$value>0就必然要往tx_vout里增加一条记录，否则$value就没有被统计进去:
			Db::query("
				INSERT INTO tx_vout SET 
					tid=".$mTransaction->tid.",
					n=".$out['n'].",
					address='".$addr."',
					value=".$value.",
					spentbytid=0 
			");
			if($addr != 'unrecognize'){
				MAddress::save('addr_in_outputpoint',$addr,$value,$mTransaction);
			}
		}else{
			/*  bug：另外两种情况：
					$value=0时,不理解这种vout的意义,不知道是否应该记录，反正0金额是不可能被以后的交易引用做输入点了，且不记录
					$value<0的情况没见过
			*/
		}
		
	}//ok
	
	//取的本vout所影响的地址一个：
	private static function getAddr(&$scriptPubKey){
		$addr = '';
		if( array_key_exists('addresses',$scriptPubKey) ){
			$addresses = & $scriptPubKey['addresses'];
			if( is_array($addresses) ){
				$addr = $addresses[0];
			}else if( is_string($addresses) ){
				$addr = $addresses;
			}
		}
		//有一些特殊类型的交易，地址不存在或无法识别：
		//如type=nonstandard (其余的type没见过不知道)
		if( !$addr || strlen($addr)!=34){
			$addr = 'unrecognize';//需要标记为unrecognize
		}
		return $addr;
	}//ok
	
}

class MAddress{

	//更新余额,添加映射
	public static function save($io,$addr,$value,$mTransaction){
		//准备两个需要用到SQL里的参数：
		$height = $mTransaction->mBlock->block['height'];
		$updateTime = $mTransaction->txdetail['time'];
		//从余额表中获取$addrid:
		$addrid = Db::getGrid("
			SELECT id FROM addr_balance WHERE addr='$addr' 
		");
		if(!$addrid){//余额表记录添加:
			//!$addrid证明这个地址是新的，那么该地址只可能出现在本交易里的vout里
			//，那么$value 一定是正数，可保存进余额里
			Db::query("
				INSERT INTO addr_balance SET 
					addr = '$addr',
					balance = ".$value.",
					updateHeight = ".$height.",
					updateTime = ".$updateTime.",
					num_tx = 1,
					amount_input = $value 
			");
			$addrid = Db::insert_id();
			//既然该地址是新的，那么isMappingExist必然是false的，就不需要再调用isMappingExist方法了:
			if($addrid>0) self::addMapping($io,$value,$addrid,$mTransaction->tid);//添加映射
		}else{//余额表记录刷新
			//这个地址已经存在，但可能还没有“建立地址-交易映射”：
			if( self::isMappingExist($addrid,$mTransaction->tid) ){//如果存在映射，就更新映射的io_balance值：
				self::updateMapping($io,$value,$addrid,$mTransaction->tid);
				//如果一个地址同时出现在vint和vout，很可能vout的那个是余额回退
				//,那么执行到vout的那个地址时就会遇到isMappingExist = true
				//,这时num_tx就不应该+1
				$NUM_TX = '';//该地址涉及的交易数不增加
			}else{//如果不存在映射：
				self::addMapping($io,$value,$addrid,$mTransaction->tid);
				$NUM_TX = ' , num_tx = num_tx + 1 ';//该地址涉及的交易数加一
			}
			if( $io == 'addr_in_outputpoint'){
				$operator = '+';
				$AMOUNT_INPUT = ' , amount_input = amount_input + '.$value;
			}else{ // if( $io == 'addr_in_inputpoint' ){
				$operator = '-';
				$AMOUNT_INPUT = '';
			}
			Db::query("
				UPDATE addr_balance SET 
					balance = balance $operator ".$value.",
					updateHeight = ".$height.",
					updateTime = ".$updateTime." 
					$NUM_TX 
					$AMOUNT_INPUT 
				WHERE id=$addrid 
			");// addr = '$addr', 这句不用写进SQL
		}
	}//ok
	
	//往“地址-交易”映射表里添加记录，以便查询某地址的所有交易：
	private static function addMapping($io,$value,$addrid,$tid){
		$OP = ( $io == 'addr_in_outputpoint') ? '+' : '-';
		Db::query("
			INSERT INTO addr_tx 
			SET addrid=$addrid,
				tid=$tid,
				io_balance= $OP $value
		");
	}//ok
	
	//修改io_balance ,当查看某地址的交易列表时要用到：
	private static function updateMapping($io,$value,$addrid,$tid){
		$OP = ( $io == 'addr_in_outputpoint') ? '+' : '-';
		Db::query("
			UPDATE addr_tx 
			SET io_balance = io_balance $OP $value 
			WHERE addrid=$addrid AND tid=$tid 
		");
	}//
	
	/*
		要查找是否已经存在addrid-tid的映射关系了，因为一个交易里
		的VIN和VOUT所涉及的地址可能有交集,必须避免重复记录和重复统计
	*/
	private static function isMappingExist($addrid,$tid){
		$row = Db::getRow('
			SELECT * FROM addr_tx WHERE addrid='.$addrid.' AND tid='.$tid.'
		');
		return $row ? true : false;
	}//ok
}

//余额排行表
class MTop{
	//刷新表
	public function refresh(){
		//刷新余额排行表
		if($this->checktime()){
			$this->clear();
			$this->fill();
		}
		//刷新每周前100名的余额总和表
		if($this->checkweekly()){
			$this->addWeekly();
		}
	}//ok
	
	//清空表
	private function clear(){
		Db::query('truncate table top');
	}//ok
	//填充表
	private function fill(){
		Db::query('
			INSERT INTO top(balance,addrid) SELECT balance,id FROM addr_balance WHERE balance>0
		');
	}//ok
	//检测时间是否足够去刷新表
	private function checktime(){
		$lastRefreshTime = Db::getGrid('SELECT top_refresh_time FROM info LIMIT 1');
		$timenow = time();
		if( $timenow - $lastRefreshTime >24*3600 ){//规定一天刷新一次
			Db::query('UPDATE info SET top_refresh_time='.$timenow);
			return true;
		}else{
			return false;
		}
	}//ok
	//检测时间是否足够去添加top_weekly表
	private function checkweekly(){
		$lastRefreshTime = Db::getGrid('SELECT weekly_refresh_time FROM info LIMIT 1');
		$timenow = time();
		if( $timenow - $lastRefreshTime > 7*24*3600 ){//规定一周添加一条记录
			Db::query('UPDATE info SET weekly_refresh_time='.$timenow);
			return true;
		}else{
			return false;
		}
	}//ok
	
	private function addWeekly(){
		//不可以用SELECT sum()...因为不管LIMIT多少都会把全部记录都统计了
		$rows = Db::getRows('
						SELECT balance FROM top 
						ORDER BY balance DESC
						LIMIT 100
		');
		$total = 0;
		if($rows){
			foreach($rows as $row){
				$total += $row['balance'];
			}
		}
		$bool = Db::query("
			INSERT INTO top_weekly SET created='".time()."',total=$total
		");
		return $bool;
	}//ok
}//ok

?>
