<?
//首页
class PageIndex{
	//取得最新的$n个区块
	public static function getBlocksLatest($n){
		$rows = Db::getRows('
					SELECT * FROM block 
					ORDER BY height DESC 
					LIMIT '.$n
			    );
		return $rows;
	}//ok
	
	//获取余额排行前4条(首页右侧用)
	public static function getToppest4(){
		$rows = Db::getRows("
					SELECT t.balance AS b,a.addr AS a 
					FROM top AS t 
					LEFT JOIN addr_balance AS a 
					ON t.addrid=a.id
					ORDER BY t.balance DESC
					LIMIT 4
				");
		return $rows;
	}//ok
	
	//取得Mempool中的最新$n个交易，不足$n个就到区块中取
	//这个函数且不使用，函数名加两个下划线。因为缓存的交易显示有难度，我决定暂时只显示数据库里的最新n条交易。见同名函数getTxLatest($n,$rpc);
	public static function __getTxLatest($n,$rpc){
		$result = array();
		$pool_tx = $rpc->getrawmempool();
		for($i=0;$i<$n;$i++){
			if( array_key_exists($i,$pool_tx) ){
				$result[$i] = self::transalateTx($pool_tx[$i],$rpc);
			}
		}
		$count = count($result);
		if($count < $n){
			$confirmed_tx = Db::getRows('SELECT * FROM tx ORDER BY id DESC LIMIT '. ($n-$count) );
			if($confirmed_tx){
				foreach($confirmed_tx as $tx){
					$tx = self::addVinVout($tx);
					$result[] = $tx;
				}
			}
		}
		return $result;
	}//ok
	
	public static function getTxLatest($n,$rpc){
		$result = array();
		$confirmed_tx = Db::getRows('SELECT * FROM tx ORDER BY id DESC LIMIT '. $n );
		if($confirmed_tx){
			foreach($confirmed_tx as $tx){
				$tx = self::addVinVout($tx);
				$result[] = $tx;
			}
		}
		return $result;
	}//ok
	
	//把tx转化为想要的格式
	private static function transalateTx(&$txid,$rpc){
		$tx = $rpc->gettransaction($txid);
		function getVinAddr(&$tx){
			foreach( $tx['vin'] as $vin ){
				if($vin['coinbase']){
					$vin_addr = '新区块奖励';
					break;
				}
				if($vin['txid']){
					$tid = Db::getGrid("SELECT id FROM tx WHERE txid = '".$vin['txid']."' ");
					$vin_addr = Db::getGrid("SELECT address FROM tx_vout WHERE tid=$tid AND n=".$vin['vout']);
					break;//取得一个地址就够了
				}
			}
			return $vin_addr;
		}//ok
		function getVoutAddr(&$tx){
			foreach( $tx['vout'] as $vout ){
				if( $vout['value']>0 ){
					$vout_addr = $vout['scriptPubKey']['addresses'][0];
					break;//取得一个地址就够了
				}
			}
			return $vout_addr;
		}
		function getOutputAmount(&$tx){
			$output_amount = 0;
			foreach( $tx['vout'] as $vout ){
				if( $vout['value']>0 ){
					$output_amount += $vout['value']*100000000;//单位聪
				}
			}
			return $output_amount;
		}
		return array(
			'vin_a'=> getVinAddr($tx) ,//第一个输入的地址
			'txtime'=> $tx['time'] ,//tx里的time 
			'vout_a'=>getVoutAddr($tx) ,//第一个输出的地址
			'txid'=>$tx['txid'],//交易ID
			'output_amount'=> getOutputAmount($tx),//转出总额,单位聪
		);
	}//ok
	
	//给交易增加一个输入口和输出口
	private static function addVinVout($tx){
		$tid = $tx['id'];
		//echo $tid,'<br>';
		$vin_a = Db::getGrid("SELECT address FROM tx_vout WHERE spentbytid=$tid LIMIT 1");
		if(!$vin_a) $vin_a = '新区块奖励';
		$vout_a = Db::getGrid("SELECT address FROM tx_vout WHERE tid=$tid LIMIT 1");
		if(!$vout_a) $vout_a = '非标准交易无地址';
		$tx['vin_a'] = $vin_a;
		$tx['vout_a'] = $vout_a;
		return $tx;
	}//ok
	
	
}//ok

//block详情页
class PageBlock{
	
	//取得区块详情
	public static function getBlockDetail($hash_or_height){
		$hh = $hash_or_height;
		if( strlen($hh)==64 ){
			$SQL_WHERE = " WHERE hash='$hh' ";
		}else{
			$hh = intval($hh);
			$SQL_WHERE = " WHERE height='$hh' ";
		}
		$row = Db::getRow("
					SELECT * FROM block $SQL_WHERE 
			    ");
		return $row;
	}//ok
	
	//取得区块中的所有交易
	public static function getTxsByBlock($hash_or_height,$rows,$start=null){
		if($start) $SQL_START = $start.',';
		$hh = $hash_or_height;
		$height = ( strlen($hh)==64 ) 
			? Db::getGrid("SELECT height FROM block WHERE hash='$hh' " )
			: intval($hh) ;
		if($height>0){
			$transactions = Db::getRows("
					SELECT * FROM tx 
					WHERE height=$height 
					ORDER BY id ASC
					LIMIT $SQL_START $rows "
			    );
			
			if($transactions){
				$blockTxs = TxIO::addVinVoutToTxs($transactions);
			}
			
		}
		return $blockTxs;
	}
	
	
	
}

//负责交易的输入输出口的处理
class TxIO{
	
	//获取具有输入口和输出口数据的交易列表：
	public static function addVinVoutToTxs(&$transactions){
		$txs = array();
		if( $transactions ){
			foreach( $transactions as $tx){
				$tid = $tx['id'];
				$txs[ $tid ] = $tx;//创建有元素索引的tx数组
				$tids[] = $tid;
			}
			$transactions = null;//旧的数组丢弃，清空内存
			$tids = implode(',',$tids);
			$txs = self::findVin($txs,$tids);
			$txs = self::findVout($txs,$tids);
		}
		return $txs;
	}
	
	//交易添加输入口：
	private static function findVin(&$txs,$tids){
		//获取所有相关的输入口：
		$tx_vins = Db::getRows("
			SELECT * FROM tx_vout WHERE spentbytid IN($tids)
		");
		//输入口添加进交易
		if( count($tx_vins)>0 ){
			foreach($tx_vins as $vin){
				$tid = $vin['spentbytid'];
				$txs[$tid]['vin'][] = $vin;
			}
		}
		return $txs;
	}
	//交易添加输出口：
	private static function findVout(&$txs,$tids){
		//获取所有相关的输出口：
		$tx_vouts = Db::getRows("
			SELECT * FROM tx_vout WHERE tid IN($tids)
		");
		//输出口添加进交易
		if( count($tx_vouts)>0 ){
			foreach($tx_vouts as $vout){
				$tid = $vout['tid'];
				$n = $vout['n'];
				$txs[$tid]['vout'][$n] = $vout;
			}
		}
		return $txs;
	}
}
//tx详情页
class PageTx{
	
	//取得交易详情(tx详情页)
	public static function getTxDetail($txid){
		$txdetail = Db::getRow("
			SELECT t.*,b.time AS btime,b.hash AS bhash 
			FROM tx AS t 
			LEFT JOIN block AS b 
			ON b.height = t.height 
			WHERE t.txid='$txid' ");
		return $txdetail;
	}//ok 
	
	public static function getTxVins($tid){
		$tx_vins = Db::getRows("
			SELECT a.*,b.txid 
			FROM tx_vout as a 
			LEFT JOIN tx as b 
			ON a.tid = b.id 
			WHERE spentbytid = $tid 
		");
		return $tx_vins;
	}//ok
	
	public static function getTxVouts($tid){
		$tx_vouts = Db::getRows("
			SELECT a.*,b.txid  
			FROM tx_vout as a 
			LEFT JOIN tx as b 
			ON a.spentbytid=b.id 
			WHERE a.tid = $tid 
		");
		return $tx_vouts;
	}//ok
	
	public static function getTxDetailFromPool($txid,$rpc){
		$txdetail = $rpc->gettransaction($txid);
		$txdetail = self::transalateTx($txdetail);
		return $txdetail;
	}
	
	//把tx转化为想要的格式
	private static function transalateTx($tx){
		//未完成
		/*
		function getVinAddr(&$tx){
			foreach( $tx['vin'] as $vin ){
				if($vin['txid'] && $vin['vout']){
					$tid = Db::getGrid("SELECT id FROM tx WHERE txid = '".$tx['txid']."' ");
					$vin_addr = Db::getGrid("SELECT address FROM tx_vout WHERE  spentbytid=$tid ");
					break;//取得一个地址就够了
				}
			}
			return $vin_addr;
		}
		*/
	}
	
}
//address详情页
class PageAddress{

	public static function getAddressDetail($addr){
		$row = Db::getRow("
				SELECT a.*,t.rank,t.ranktime,t.rankper FROM addr_balance AS a
				LEFT JOIN top AS t
				ON t.addrid = a.id 
				WHERE a.addr='$addr' 
			");
		//获取余额排名：
		if(!$row['rank']){
			//取得本地址的排名：
			$rank = Db::getGrid("SELECT count(*) FROM top WHERE balance>".$row['balance']);
			$rank = $rank+1;
			$num_addr = Db::getGrid("SELECT count(*) FROM top");//top表里全是余额大于零的地址
			$rankper = $num_addr>0 
									? round( ($rank/$num_addr)*100,2 ) 
									: 0;
			$time = time();
			//保存排名：
			Db::query("UPDATE top SET rank=$rank,ranktime=$time,rankper=$rankper           WHERE addrid = $addrid");
			$row['rank'] = $rank;
			$row['rankper'] = $rankper;
			$row['ranktime'] = $time;
		}
		return $row;
	}//ok
	
	//取得和地址有关的交易列表
	public static function getTxsByAddr($addr,$remain=null){
		$row_addr = Db::getRow("
			SELECT * FROM addr_balance 
			WHERE addr='$addr' 
		");
		$addrid = $row_addr['id'];
		if($addrid){
			//结果集可能很大，无法一下子加载到网页中，所以我猜火币网程序员把结果集断开为两部分，第一部分是最新的5笔交易，先发送到浏览器端，其余的是第二部分，在浏览器端显示完第一部分后发请求来获取。
			if($remain){
				//bug:
				/*
					结果集的第二部分如果下面这么写，依旧可能很大:
					$SQL_LIMIT = " LIMIT 0,$break ";
					所以改用下面这句，只取100条交易，太早的交易就不显示了，没意义
					虽然没意义但是毕竟没有完全显示出来，所以这是一个bug
				*/
				if($row_addr['num_tx']>5){//仅当交易数大于5条时才有所谓的第二部分
					$num_show = 100;//第二部分我只想显示100条
					$num_remain = $row_addr['num_tx']-5;//num_remain是第二部分的数据总数
					if($num_remain<=$num_show){
						$SQL_LIMIT = " LIMIT 0,$num_remain ";
					}else{
						$start = $num_remain - $num_show;//$start一定大于零
						$SQL_LIMIT = " LIMIT $start,$num_show ";
					}
				}
			}else{
				//这是结果集的第一部分：
				$break = $row_addr['num_tx']-5;	
				if($break<0) $break=0; 
				$SQL_LIMIT = " LIMIT $break,5";
			}
			
			//注意，这里比较特殊，要升序排列，到了客户端，JAVASCRIPT会逆序。地址的新交易总是要显示在最上端的。
			$transactions = Db::getRows("
					SELECT a.io_balance,t.* FROM addr_tx AS a
					LEFT JOIN tx AS t 
					ON a.tid = t.id 
					WHERE a.addrid=$addrid
					ORDER BY a.tid ASC 
					$SQL_LIMIT
			    ");
			
			//print_r($transactions);die;
			$addrTxs = TxIO::addVinVoutToTxs($transactions);
		}
		return $addrTxs;
	}//ok
	
}//ok

class Map{
	
}

//余额排行表
class Top{
	//获取前n条排行(余额排行页显示50个、首页显示4个最有钱地址)
	public function getToppest($n){
		$rows = Db::getRows("
					SELECT t.balance,t.addrid,a.addr,a.updateTime 
					FROM top AS t 
					LEFT JOIN addr_balance AS a 
					ON t.addrid=a.id
					ORDER BY t.balance DESC
					LIMIT $n
				");
		return $rows;
	}//ok
}//ok

?>