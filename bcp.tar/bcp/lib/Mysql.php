<?php
class Db{
	public static $link;
	public static $config;
	
	public static function init($config){
		self::$config = $config;
		self::connect();
	}
	private static function connect(){
		$c = self::$config;
		self::$link = @mysqli_connect($c['hostname'],$c['username'],$c['password']);
		if(!AUTOUPDATE){//如果本页不是由数据自动更新程序调用的，就尝试报错
			if (!self::$link)
			die('<meta charset="utf-8">数据库连接失败'); 
		}
		@mysqli_select_db(self::$link,$c['database']);
		return @mysqli_query(self::$link,"SET NAMES '".$c['charset']."';");
	}	
	//对二维数组（表格）进行冒泡排序,排序的根据是表的某个栏
	public static function bubble_sort(&$list,$column){
		$len = count($list);
		if( $len < 2 ) return false;
		for($key = 1;$key< $len;$key++){
			$temp = $list[$key];
			for($i=$key-1;$i>=0;$i--){
				if( $temp[$column] > $list[$i][$column] ){
					$list[$i+1] = $list[$i];
					continue;
				}else{
					break;
				}
			}
			$list[$i+1] = $temp;
		}
		return true;
	}	
	public static function getRow($sql){//select one row
		$result=self::query($sql);
		if(!$result) return false;
		$row = mysqli_fetch_assoc($result);
		return $row;
	}	
	public static function getRows($sql){//select many rows
		$result = self::query($sql);
		if(!$result) return false;
		$rows = array();
		while ($row = mysqli_fetch_assoc($result)){
			$rows[] = $row;
		}
		return $rows;
	}	
	public static function getGrid($sql){//select one column from one row
		$result=self::query($sql);
		if(!$result) return false;
		$row = mysqli_fetch_assoc($result);
		if( empty($row) ) return false; 
		$grid = array_pop($row);
		return $grid;
	}	
	public static function query($sql){
		//return mysqli_query(self::$link,$sql) or die(mysqli_error(self::$link));
		//使用上面这句会导致不返回数据集对象再导致报错
		return mysqli_query(self::$link,$sql);
	}	
	public static function reconnect(){//供数据自动更新程序用
		if(self::$link) @mysqli_close(self::$link);
		return self::connect();
	}	
	public static function insert_id(){
		return mysqli_insert_id(self::$link);
	}
	public static function escape($str){//防注入
		return mysqli_real_escape_string(self::$link,$str);
	}
	
	public static function getPrimaryKeys($sql){
		$rows = self::getRows($sql);
		if($rows && count($rows)>0){
			$keys = array();
			foreach($rows as $row){
				$keys[] = $row['id'];
			}
			$keys = implode(',',$keys);
		}else{
			$keys = '';
		}
		return $keys;
	}
	
	public static function limit($currentPage=1,$pageSize){
		if(!is_null($pageSize) && !is_null($currentPage)){
			$offset = ($currentPage-1)*$pageSize;
			$limit = " LIMIT $offset,$pageSize ";
		}
		return $limit;
	}
}
?>
