//i18n
String.locale = "zh_CN";
String.toLocaleString({
    "en_US":"/static/js/lang/en.json",
    "zh_CN":"/static/js/lang/zh.json"
});
var l = function (string) {
    var tran = string.toLocaleString();
    return tran;
};
