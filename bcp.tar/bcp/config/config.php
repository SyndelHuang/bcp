<?php
/*
配置说明：
1.cache目录及内部文件都要设置成777,config里面的txt也要777
2.URL重写
2.1 apache要启用mod_rewrite模块
2.2 nginx实现URL重写请使用try_files：
    location / {
		try_files $uri /index.php?$args;
	}

 如有疑问请联系qq 375241242    
*/


//服务器：139.129.109.13  root 密码LIshuang~!@
   //这个服务器的mysql-server是root 123456

$admin_password = 'root';
//时区配置：
date_default_timezone_set('Etc/GMT+0');//时区不要改了，所有服务器统一，以保证统计图表的记录在日期上的统一
//URL重定向相关配置：
define('ROOT',1);//防止访问内部controller文件的机制
$separator = '/';//index.php所在的目录名（末尾必须有/号、如果该目录没有显示在URL上就写/）
//数据库配置：

$db_config = array(
	'hostname'=>'127.0.0.1',//数据库地址和端口
	'username' => 'root',//数据库用户名
	'password' => 'root',//数据库密码
	'database' => 'mychain',//库名
	'charset' => 'utf8'//字符集
);

define('PORT_COIN',16500);//加密货币RPC端口

$rpcuser = 'abc';
$rpcpass = '123';

$GLOBALS['coin'] = [
	'name'=>'玛雅币'
];
?>
