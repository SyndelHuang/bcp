<?
//print_r($args);die;
//print_r(json_decode('',true));die;
//echo date('y-m-d h:i:s',1459375324);die;

// 行情API:http://abwang.com/about/index.html?id=14

{//连接MYSQL
	define('AUTOUPDATE',false);
	include_once('lib/Mysql.php');
	Db::init($db_config);
}

include_once('lib/BlockChainReader.php');

function response_json($array){
	$json = json_encode($array);
	$cb = $_GET['callback'];
	if($cb){
		$json = $cb.'('.$json.')';
	}
	echo $json;
}

function curlread($link="")
{
	$ch = curl_init();
	$timeout = 12;
	curl_setopt ($ch, CURLOPT_URL,$link);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Connection: close'
		//'Keep-Alive: 300'
	   ));
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_HEADER,0);
	curl_setopt ($ch, CURLOPT_NOBODY,0);
	curl_setopt ($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36');
	//curl_setopt ($ch, CURLOPT_USERAGENT, ' Chrome/46.0.2490.86 ');
	//curl_setopt ($ch, CURLOPT_USERAGENT, ' Chrome/46.0.2490.85 ');
		//curl_setopt ($ch, CURLOPT_USERAGENT, 'Safari/5.34.57.2 ');
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	//echo '@';
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}

switch($args[2]){
	case 'tx':{//ok 除了2个疑惑：1. tts这个变量好像没啥用，我没加。 2.缓存池的交易尚无法显示
		$txid = $args[3];
		$tx = PageTx::getTxDetail($txid);
		if($tx){
			//$topHeight这个变量用于推理出确认数cf:
			$topHeight = Db::getGrid('SELECT blocks FROM info');
			$json_tx = array(
				'a'=>array(),// 该交易的所有输入口和输出口的集合，如果是输入口就必须显示为负数,且置空，后面处理
				'vf'=>$tx['fee'],//矿工费,单位聪
				'vi'=>array(),//输入口集合,且置空，后面处理
				'bh'=>$tx['height'],//所属区块
				'cf'=>$topHeight - $tx['height'],// 确认次数,可推算无需存储
				'vo'=>array(),// 输出口vout,且置空，后面处理
				'bt'=>date('Y-m-d h:i:s',$tx['btime']),//包含进区块时的时间
				'r'=>date('Y-m-d h:i:s',$tx['txtime']),//mempool接收到这交易的时间
				'v'=>$tx['output_amount'],//转出总额
				'bhash'=>$tx['bhash'],//所属区块的哈希
				'id'=>$tx['txid']//交易ID
			);
			$a = array();
			//对输入口的处理：
			$tx_vins = PageTx::getTxVins($tx['id']);
			if($tx_vins){
				foreach($tx_vins as $vin){
					$json_tx['vi'][] = array(
						'a'=>array($vin['address']),
						't'=>$vin['txid'],
						'v'=>$vin['value']
					);
					$a[] = array(
						'a'=> $vin['address'],
						'v'=> -1 * $vin['value'] //标记为负数，反正火币网程序员这么干我抄它前端只好也这么干
					);
				}
			}//ok
			if($tx['coinbase']){
				$json_tx['cb'] = $tx['coinbase'];
				//值至少要留个空格，才能在浏览器上显示“新区块奖励” ，但不知是否有旷工会故意留空字符串
			}
			//对输出口的处理：
			$tx_vouts = PageTx::getTxVouts($tx['id']);
			if($tx_vouts){
				foreach($tx_vouts as $vout){
					$json_tx['vo'][] = array(
						'a'=>array($vout['address']),
						//'tts'=>//这个是tt的复数，数组。因为我不认为这个数组有啥用所以去掉了
						'tt'=>$vout['txid'],//如果这个输出口的钱已经被花了，就填写花费它的交易的ID
						'v'=>$vout['value'] //输出额，单位聪
					);
					$a[] = array(
						'a'=> $vout['address'],
						'v'=> $vout['value']
					);
				}
			}//ok
			//对输入输出的集合的处理：
			$json_tx['a'] = $a;
			/*
			bug:其实不是我的bug，是ECO的。这个交易a051a3c6c16bfec3836b0984bb35c6fac6b97189a1f53b5f14fd132f3d9be9b0
			的手续费是0，这是因为对交易手续费的计算是用输入总额减去输出总额，但这个奇特的交易居然输入小于输出，导致负数的交易费不会被存储进MYSQL。我的程序是没错的，错的是这个交易很不合理。算了，山寨币不知道在搞什么。			
			*/
		}//ok
		response_json($json_tx);
	}
	break;
	case 'address':{//EKmTmQJPse2CUCVLDDhuKkiuPG7Mr5pPJ3 这个地址的交易很多可供测试 
	//另外还有一些标记为 nook 的地方可改进
		$address = $args[3];
		if( strlen($address)==34 ){
			$addr = PageAddress::getAddressDetail($address);
			$json_addr = array(
				'c'=>$addr['num_tx'],//交易次数
				'b'=>$addr['balance'],//余额 balance
				'i'=>$addr['amount_input'],//转入总额 input
				'tu'=>array(),//nook //tx unconfirmed 的缩写，目前我并没支持这个功能
				'u'=>0,//nook  //unconfirmed 未确认的余额，目前我并没支持这个功能
				't0'=>array(),//nook //address.js中查不到t0字样
				't'=>array(),//ok 取最迟的5条并按交易生成时间的升序排列
				'rankper'=>$addr['rankper'],//余额排名百分比（位于前4.02%）,这个参数只有在top排行榜里的地址才有
				'rank'=>$addr['rank'],//余额排名,这个参数只有在top排行榜里的地址才有
				'id'=>$addr['addr'],//正在查询的地址
				'rk'=>array(//无法在address.js中找到rk字样
						'r'=>$addr['ranktime'], //这是一个timestamp,对某个地址计算其排名，是在一个排名表上取大于这个地址的余额的其它地址的总数，这种计算比较耗时所以平时是不算的，当有人查看某个地址而该地址尚无排名时时才实时地去算，而计算完毕的时刻就是r
						'b'=>$addr['balance'],//余额
						'n'=>$addr['rank']//余额排名
					)
			);
			//添加该地址的最新的5条交易：
			  //( 交易一定要写5以上,不能写1234,这样当交易满5条的时候，js就会自动加载更多的交易，见address.js:if(a.t.length >=5) )
			$txs = PageAddress::getTxsByAddr($address,$_GET['remain']);
			if($txs){
				$topHeight = Db::getGrid('SELECT blocks FROM info');//区块高度
				foreach($txs as $tx){//这里逐条发SQL请求，效率恐怕不好，特别是当一个地址有上千个交易时....
					//对该交易的输入口的处理：
					$VI = array();
					$tx_vins = PageTx::getTxVins($tx['id']);
					if($tx_vins){
						foreach($tx_vins as $vin){
							$VI[] = array(
								'a'=>array($vin['address']),
								't'=>$vin['txid'],
								'v'=>$vin['value']
							);
						}
					}//ok
					//对该交易的输出口的处理：
					$VO = array();
					$tx_vouts = PageTx::getTxVouts($tx['id']);
					if($tx_vouts){
						foreach($tx_vouts as $vout){
							$VO[] = array(
								'a'=>array($vout['address']),
								//'tts'=>//这个是tt的复数，数组。因为我不认为这个数组有啥用所以去掉了
								'tt'=>$vout['txid'],//如果这个输出口的钱已经被花了，就填写花费它的交易的ID
								'v'=>$vout['value'] //输出额，单位聪
							);
						}
					}//ok
					//把该交易添加进最终结果数组里：
					$json_addr['t'][] = array(
						'b'=>$tx['io_balance'],// io_balance，单位聪，该交易对该地址的余额的增减量。
						'vi'=>$VI,//输入口,如果是空数组的就会被前端界面识别为新区块奖励
						'cf'=>$topHeight - $tx['height'],//确认数
						'vo'=>$VO,//输出口
						'r'=>date('Y-m-d h:i:s',$tx['txtime']),//交易接收时间（非包含进区块的时间）
						't'=>$tx['txid'],//txid
					);
					 
				}
			}
			
		}
		response_json($json_addr);
	}
	break;
	case 'blocktx':{//ok,每页显示25个交易，更多的话可点击网页上的“显示更多”
		$height = $args[3];
		$start = $_GET['start'];//整型,从第$start条记录开始读取.
		$blockTxs = array();
		$txs = PageBlock::getTxsByBlock($height,25,$start);
		if($txs){
			foreach($txs as $tx){
				//对该交易的输入口的处理：
				$VI = array();
				$tx_vins = PageTx::getTxVins($tx['id']);
				if($tx_vins){
					foreach($tx_vins as $vin){
						$VI[] = array(
							'a'=>array($vin['address']),
							//'t'=>$vin['txid'],//在blocktx这个case里面没用到
							'v'=>$vin['value']
						);
					}
				}//ok
				//对该交易的输出口的处理：
				$VO = array();
				$tx_vouts = PageTx::getTxVouts($tx['id']);
				if($tx_vouts){
					foreach($tx_vouts as $vout){
						$VO[] = array(
							'a'=>array($vout['address']),
							//'tts'=>//这个是tt的复数，数组。在blocktx这个case里面没用到
							//'tt'=>$vout['txid'],//如果这个输出口的钱已经被花了，就填写花费它的交易的ID。在blocktx这个case里面没用到
							'v'=>$vout['value'] //输出额，单位聪
						);
					}
				}//ok
				
				$bTx = array(
					'r'=>date('Y-m-d h:i:s',$tx['txtime']),//交易生成时间
					'id'=>$tx['txid'],//交易ID
					'vo'=>$VO //输出口
				);
				if($tx['coinbase']){//bug：是否可能有旷工会留个空白的言？
					$bTx['cb'] = $tx['coinbase'];
				}else{
					$bTx['vi'] = $VI;//输入口
				}
				$blockTxs[]= $bTx;//不可以用&号传址，因为是在foreach中
			}
		}
		response_json($blockTxs);
	}
	break;
	case 'block':{//ok
		$hash_or_height = $args[3];
		$block = PageBlock::getBlockDetail($hash_or_height);
		$topHeight = Db::getGrid('SELECT blocks FROM info');
		$json_block = array(
			'merkleroot'=>$block['merkleroot'],//麦克莱根
			'nonce'=>$block['nonce'],//随机数
			'previousblockhash'=>$block['previousblockhash'],//上一区块哈希
			'hash'=>$block['hash'],//本区块哈希
			//'chainwork'=>$block['chaintrust'],//不用翻译,区块链中只有chaintrust，要改一下js文件
			'minerpool'=>'',//挖出方
			'v'=>$block['output_amount'],//总发送额，需要统计
			'count'=>$block['num_tx'],//交易笔数
			'height'=>$block['height'],//高度
			'difficulty'=>$block['difficulty'],//难度系数
			'nextblockhash'=>$block['nextblockhash'],//下一区块哈希
			'version'=>$block['version'],//版本号
			'confirmations'=>$topHeight - $block['height'],//确认数
			'time'=>date('Y-m-d h:i:s',$block['time']),//生成时间
			'bits'=>$block['bits'],//计算目标。（16进制数）有些区块浏览器转换成10进制数显示
			'size'=>$block['size']//数据量(kb)
		);
		response_json($json_block);
	}
	break;
	case 'info':{//只缺市场价格的接口了
		$info = $rpc->getinfo();
		$lastBlock = $rpc->getblockbynumber($info['blocks']);
		$mininginfo = $rpc->getmininginfo();
		$ticker_json = fopen('http://www.abwang.com/json/topQuotations.html?symbol=18','rb');
		$ticker = "";
		while (!feof($ticker_json)) {
		    $ticker .= fread($ticker_json, 10000);
		}
		fclose($ticker_json);
		$ticker = json_decode($ticker,true);
		$arr = array(
			'hash' => $lastBlock['hash'],
			'hashps' => '',//全网算力
			'top' => PageIndex::getToppest4(),//余额排行，从高到低4个，ok了
			'height' => $info['blocks'],
			'difficulty' => $info['difficulty'],//另外还有proof-of-work
			//'time' => ,//查看了index.js,这参数好像没用，并没有被显示出来
			'pools' => array(),//算力排行，无
			'poollength' => $mininginfo['pooledtx'],//待确认交易条数
			'moneysupply' => $info['moneysupply'],
			'ticker' => array(//市场价格
				'abwang'=>array(
						0=>'爱币网',//交易所名称,中文
						1=>$ticker['buyone']?$ticker['buyone']:0,//人民币价格 
						2=>'http://abwang.com/',//交易所地址
						3=>'abwang',//交易所名称，英文
						4=>0//美元价格，暂不支持
				)
			)
		);	
		response_json($arr);
	}
	break;
	case 'blocks':{//ok
		$start = $_GET['start'];
		if($start){
			$blocks = PageIndex::getBlocksLatest(100);
		}else{
			$blocks = PageIndex::getBlocksLatest(6);
		}
		$json_blocks = array();
		if($blocks){
			foreach($blocks as $key=>$b){
				$json_blocks[$key] = array(
					'count'=>$b['num_tx'],//交易数
					'poolurl'=>'',//挖出方地址
					'hash'=>$b['hash'],//块哈希
					'cb'=>'',//挖出方
					'minerpool'=>'',//挖出方
					'time'=>date('Y-m-d h:i:s',$b['time']),//生成时间
					'height'=>$b['height'],//区块高度
					'v'=>$b['output_amount'],//总发送额
					'size'=>$b['size']  //数据量（kb）
				);	
			}
			
		}
		$json_blocks = array('block'=>$json_blocks );
		response_json($json_blocks);
	}
	break;
	case 'txs':{//ok
		$json_txs = array();
		$txs = PageIndex::getTxLatest(9,$rpc);
		if($txs){
			foreach($txs as $key=>$tx){
				$json_txs[$key] = array(
					'vin_a'=>$tx['vin_a'],//第一个输入
					'r'=> round( (time()-$tx['txtime'])/60,0),//也就是挖出时间距离现在多少分钟，在网页上显示为“<0分钟”的字样
					'vout_a'=>$tx['vout_a'],//第一个输出
					'id'=>$tx['txid'],//交易ID
					'v'=>$tx['output_amount'],//转出总额,单位聪。注意并非第一个输出的转出额，而是所有输出的总额。
				);	
			}
			
		}
		$json_txs = array('tx'=>$json_txs );
		response_json($json_txs);
	}
	break;
	case 'topaddress':{//ok
		$Top = new Top();
		$toppest = $Top->getToppest(100);
		if($toppest){
			$json_toppest = array();
			$total = 0;
			foreach($toppest as $t){
				$json_toppest['a'][] = array(
					'a'=>$t['addr'],//地址
					'b'=>$t['balance'],//余额，单位聪
					'l'=>date('Y-m-d h:i:s',$t['updateTime'])//最后一次交易时间,我猜是最后一次交易所在的区块的创建时间或者交易本身所记录的时间
				);
				$total += $t['balance'];
			}

			{//总金额和上周、上月的对比：
				$totals = Db::getRows('SELECT * FROM top_weekly ORDER BY week DESC LIMIT 4');
				//上周和上月的总金额,单位聪：
				$total_lweek = $totals[0] ? $totals[0]['total'] : 0;
				$total_lmonth = $totals[3] ? $totals[3]['total'] : 0;
				//当前总金额，单位聪.这个总额是上述100排行的金额总和：
				$json_toppest['total'] = $total;//总额，
				//较上周增加的百分比，注意可能是负数：
				$json_toppest['lweek'] = $total_lweek>0 ? 
					round(($total/$total_lweek-1)*100,2)
					:0;//取值为零即不会显示
				//较上月增加的百分比，注意可能是负数：
				$json_toppest['lmonth'] = $total_lmonth>0 ?
					round(($total/$total_lmonth-1)*100,2)
					:0;//取值为零即不会显示
			}
		}
		response_json($json_toppest);
	}
	break;
	default:
	//最后js文件里还有一个 ws = new WebSocket("ws://api.qukuai.com:8000/ws"); 没有做出来
		echo '{"error":404}';
		/*
		异常请求情况：
			404，返回json数据：{"error":404}
			缺少参数，返回json数据：{"missing parameter"：1003}
			没有权限，返回json数据：{"no permission"：1001}
			请求频率限制，返回json数据：{"frequency limit",1002}
		*/
		break;
}
?>
