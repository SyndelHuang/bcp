<?head()?>
<div class="row">

	<div class="left">
		<div class="column-box">
		<div class="column">区块</div>
		<div class="vice">/ 最新生成的区块</div>
		<div class="more">
			<a href="/blocks">
				<img src="/static/images/jtr.png"></a></div>
		</div>
		<div class="table-responsive">
		<table class="table" id="blk_tb">
		<thead>
		<tr>
		<th class="t0">&nbsp;</th>
		<th class="t1">区块高度</th>
		<th class="t2">包含交易数</th>
		<th class="t6">总发送额</th>
		<th class="t3">数据量 (kB)</th>
		<!--th class="t4">挖出方</th-->
		<th class="t5">生成时间</th>
		<th class="t0">&nbsp;</th>
		</tr>
		</thead>
		<tbody></tbody></table>
		</div>
		<div class="clearfix"></div>
		<div class="index-line"></div>
		<div class="column-box">
		<div class="column">交易</div>
		<div class="vice">/ 最新生成的交易</div>
		</div>
		<div class="tx-box">
		<div class="table-responsive">
		<table class="table table-hover" id="tab-tx">
		<tbody></tbody></table>
		</div>
		</div>
	</div>
	<div class="right">
		<div class="data">数据</div>
		<div id="data">
		</div>
		<div class="title-box">
		<div class="title-img"><img src="/static/images/sc.png?v=61356ba3427a3c0b1d00f71b74fd93cf"></div>
		<div class="title-word">市场价格</div>
		</div>
		<div id="price">
		</div>
		<!--div class="title-box">
		<div class="title-img"><img src="/static/images/sl.png?v=a3ef746a558d3b2cace6ff61a2c14260"></div>
		<div class="title-word">算力排行</div>
		<div class="title-more"><a href="/pools" id="stress_more">更多</a></div>
		</div>
		<div id="stress_top">
		</div>
		<div class="clearfix"></div-->
		<div class="title-box">
		<div class="title-img"><img src="/static/images/ye.png?v=b413c1cdd1305431f2a2cebe4aaa1973"></div>
		<div class="title-word">余额排行</div>
		<div class="title-more"><a href="/top" id="balance_more">更多</a></div>
		</div>
		<div id="balance">
		</div>
		<div class="clearfix"></div>
		<!--div class="tag-url">
		<div class="tag-box"><a href="/tag" class="tag"><img src="/static/images/jia.png?v=bc50232875ad42ca7e883b963801287c"> 地址标签</a></div>
		<div class="tag-box"><a href="/tag?type=notes" class="tag"><img src="/static/images/jia.png?v=bc50232875ad42ca7e883b963801287c"> 交易注释</a></div>
		</div>
		<div class="qukuai-box">
		<div class="data-word"><img src="/static/images/left-y.png?v=c62c7579c7542484a68b63b3392d2f4f" class="left-y">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;它是全球唯一的，不可逆的，可能也无法终止的巨大账本。<img src="/static/images/right-y.png?v=0781123e4b9ba3faeab1d8bc0214ba74" class="right-y"></div>
		</div>

		<div class="what"><a href="/about">什么是区块链？</a></div>

		<div class="clearfix"></div-->

	</div>


</div>
<?foot()?>
<?include_once('controller/map.php')?>
<script src="/static/js/index.js"></script>
</body></html>
