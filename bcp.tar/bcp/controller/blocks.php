<?head()?>
<div class="row">

<div class="all">
<div class="all-title-box">
<div class="all-title">最新生成的区块</div>
</div>
<div class="clearfix"></div>
<div class="table-responsive moretable">
<table class="table">
<thead class="top">
<tr>
<th class="more6">&nbsp;</th>
<th class="more1">区块高度</th>
<th class="more2">包含交易数</th>
<th class="more0">总发送额</th>
<th class="more3">数据量 (kB)</th>
<th class="more5">生成时间</th>
<th class="more6">&nbsp;</th>
</tr>
</thead>
<tbody id="block_table"></tbody>
</table>
</div>
<div class="clearfix"></div>
<div class="clearfix mb100"></div>
</div>
</div>

<?foot()?>
<script src="/static/js/list.js"></script>
</body></html>
