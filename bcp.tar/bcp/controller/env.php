<?
  echo phpinfo();
?>
