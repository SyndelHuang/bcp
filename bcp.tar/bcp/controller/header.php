<?if(!ROOT) DIE;?>

<!DOCTYPE html>
<!-- saved from url=(0018)http://qukuai.com/ -->
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?=$GLOBALS['coin']['name']?>区块浏览器</title>
<meta name="viewport" content="width=320, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0 ,user-scalable = no">
<meta name="keywords" content="DomainQianbao">
<!-- Bootstrap -->
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/static/css/bootstrap.css">
<link rel="stylesheet" href="/static/css/base.css">
<script async="" src="/static/js/analytics.js"></script><script src="/static/js/jquery.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script>
//add by gabin:
var site_url = top.location.href;
var temp = site_url.split('/');
site_url = 'http://'+temp[2]+'/';//本参数被js文件中的$.getJSON方法引用
</script>
</head>
<body>


<!-- Static navbar -->
<div class="navbar navbar-inverse">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
<img src="/static/images/menu.png">
</button>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search_box">
<img src="/static/images/search.png">
</button>
<a class="navbar-brand hidden-sm qukuai" 
   href="/">
<img src="/static/images/p_logo.png" id="logo-mini"> 区块</a>

        
	<!--a class="navbar-brand hidden-sm hidden-xs " 
		href="#">图表</a>
	<a class="navbar-brand hidden-sm hidden-xs " 
		href="#">API</a>
	<a class="navbar-brand hidden-sm hidden-xs" 
		href="https://qianbao.qukuai.com/" target="_blank">快钱包</a>
	<a class="navbar-brand hidden-sm hidden-xs" 
		href="javascript:;" id="node">节点分布</a-->
		
		
</div>
<ul class="nav navbar-nav navbar-right hidden-xs" id="lang">
<li class="dropdown">
<a data-toggle="dropdown" class="dropdown-toggle" href="javascript:void(0)">Language &nbsp;&nbsp;&nbsp;&nbsp;<b class="caret"></b></a>
<ul class="dropdown-menu">

<li><a href="#">English Site</a></li>
<li><a href="#">中文站</a></li>

</ul>
</li>
</ul>


<div class="navbar-collapse collapse" id="search_box">
<ul class="nav navbar-nav">
<li class="search_p">
<form role="search" action="/search" method="GET">
<input name="search" placeholder="交易ID、地址、区块高度" class="form-control phone"><button class="phone_btn" type="submit">搜索</button>
</form>
</li>
</ul>
</div>
<div class="navbar-collapse collapse" id="menu">
<ul class="nav navbar-nav">
<!--li class="active"><a href="./index_files/index.html" class="coin">BTC</a></li>
<li class=""><a href="http://qukuai.com/ltc" class="coin">LTC</a></li>
<li class=""><a href="http://qukuai.com/api" class="coin">API</a></li>
<li class=""><a href="http://qukuai.com/charts" class="coin">图表</a></li>
<li class="qianbao"><a href="https://domainqianbao/">快钱包</a></li-->

<li><a href="#">English Site</a></li>
<li><a href="#">中文站</a></li>

</ul>
</div>
</div>
<div class="container logo-box hidden-xs">

<div class="logo"><div class="logo-img">
<a href="/">
<img src="/static/images/logo.png">
</a></div>

<div class="coin-box" style="display:none">
<a href="./index_files/index.html"><div class="scoin" id="nowcoin">MYC<span>&nbsp;<img src="/static/images/select.png"></span></div></a><a href="http://qukuai.com/ltc"><div class="scoin select">LTC</div></a></div>
</div>

<div class="search-box">

<form role="search" action="/search" method="GET">
<button class="search-btn" type="submit"><div class="button-y"><img src="/static/images/fdj.png"></div></button>
<input name="search" placeholder="交易ID、地址、区块高度" class="form-control search">
</form>
</div>
</div>
<div class="container main ">
