<div class="map-box" id="map_box" style="display:none;">
<div id="mainMap" class="mainMap"><img src="/static/images/loading.gif"></div>
<div class="map-tis-count"><a href="javascript:;" id="map_all"></a></div>
<div class="map-tis-box">
<div class="map-tis-title"><span id="nowtime"></span> &nbsp;&nbsp;&nbsp;全球比特币交易数</div>
<div class="map-tis-num" id="map_tx"></div>
<div class="map-tis-un">未确认交易：<b id="map_poollength">61913</b></div>
</div>
<div class="map-tis-info">总算力:<b id="map_hash">1082174 TH/s</b>&nbsp;&nbsp;&nbsp;总市值:<b id="map_market">¥ 399亿</b>&nbsp;&nbsp;&nbsp;难度系数:<b id="map_diff">165496835118</b></div>
<div class="map-tis-logo"><img src="/static/images/map_logo.png"></div>
</div>
<script src="/static/js/bootstrap-dialog.min.js"></script>
<script>
function getMap(){
// --- 地图 ---
var myChart2 = echarts.init(document.getElementById('mainMap'));
myChart2.setOption({
backgroundColor: '#071f2f',
color: [
'rgba(255, 119, 28, 0.8)',
'rgba(227, 173, 20, 0.8)',
'rgba(255, 255, 255, 0.8)',
],
title : {
text: '',
subtext: '',
x:'center',
textStyle : {
color: '#fff'
}
},
legend: {
orient: 'vertical',
x:-100,
data:['强','中','弱'],
textStyle : {
color: '#fff'
}
},
series : [
{
name: '弱',
type: 'map',
mapType: 'world',
itemStyle:{
normal:{
borderColor:'rgba(10,56,85,1)',
borderWidth:1,
areaStyle:{
color: '#071420'
}
}
},
roam:false,
showLegendSymbol:false,
data : [],
markPoint : {
symbolSize: 2,
large: true,
effect : {
show: true,
period: 5,
},
data : (function(){
var data = [];
var len = 3000;
var geoCoord
while(len--) {
geoCoord = placeList[len % placeList.length].geoCoord;
data.push({
name : placeList[len % placeList.length].name + len,
value : 20,
geoCoord : [
geoCoord[0] + Math.random() * 5 * -1,
geoCoord[1] + Math.random() * 3 * -1
]
})
}
return data;
})()
}
},
{
name: '中',
type: 'map',
mapType: 'world',
data : [],
markPoint : {
symbolSize: 2,
large: true,
effect : {
show: true,
period: 2,
},
data : (function(){
var data = [];
var len = 1000;
var geoCoord
while(len--) {
geoCoord = placeList[len % placeList.length].geoCoord;
data.push({
name : placeList[len % placeList.length].name + len,
value : 50,
geoCoord : [
geoCoord[0] + Math.random() * 5 * -1,
geoCoord[1] + Math.random() * 3 * -1
]
})
}
return data;
})()
}
},
{
name: '强',
type: 'map',
mapType: 'world',
hoverable: false,
data : [],
markPoint : {
symbol : 'diamond',
symbolSize: 2,
large: true,
effect : {
show: true,
period: 1,
},
data : (function(){
var data = [];
var len = placeList.length;
while(len--) {
data.push({
name : placeList[len].name,
value : 90,
geoCoord : placeList[len].geoCoord
})
}
return data;
})()
}
}
]
});
}
function randomString(len) {
　　len = len || 32;
　　var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
　　var maxPos = $chars.length;
　　var pwd = '';
　　for (i = 0; i < len; i++) {
　　　　pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
　　}
　　return pwd;
}
var dialog = null;
var op = "all"
$("#node").click(function(){
nowTime();
$('#map_box').show()
dialog = new BootstrapDialog({
message: $('#map_box'),
closable: true,
autodestroy:false,
onhidden: function(dialogRef){
clearTimeout(t);
$("#mainMap").html('<img src="/static/images/loading.gif?v=1aead32d4802ea363f11316b34237bb7">')
$("#map_all").html('');
}
});
dialog.realize();
dialog.getModalHeader().hide();
dialog.getModalFooter().hide();
win_height = $(window).height();
if(win_height> 700){
dialog_height = parseInt(win_height-700)/2;
}else{
dialog_height = 0
}
dialog.getModalDialog().css('margin',dialog_height+"px auto");
dialog.getModalBody().css('background-color', '#0088cc');
dialog.getModalBody().css('padding', 0);
dialog.open();
$.getScript("/static/js/echarts-plain-map.js", function(){
$.getScript("/static/js/ipnode.js", function(){
getMap()
$("#map_all").html('<img id="map_img" data-op="all" src="/static/images/all.png?v=f4b25d1cbe93601b7482afaac0d11451">');
});
});
})
$("#map_all").click(function(){
h_height = 700;
h_width = 1024;
$("#mainMap").html('<img src="/static/images/loading.gif">')
if(op == "all"){
dialog.getModalDialog().css('margin',"0");
dialog.getModalDialog().css('height',$(window).height());
dialog.getModalDialog().css('width',$(window).width());
dialog.getModalBody().css('height',$(window).height());
dialog.getModalBody().css('width',$(window).width());
$("#map_box").css('height',$(window).height());
$("#map_box").css('width',$(window).width());
$("#mainMap").css('height',$(window).height());
$("#mainMap").css('width',$(window).width());
$("#map_img").attr('src',"/static/images/half.png");
op = "half"
}else if(op == "half"){
dialog.getModalDialog().css('height',h_height);
dialog.getModalDialog().css('width',h_width);
dialog.getModalDialog().css('margin',"30px auto");
dialog.getModalBody().css('height',h_height);
dialog.getModalBody().css('width',h_width);
win_height = $(window).height();
if(win_height> 700){
dialog_height = parseInt(win_height-700)/2;
}else{
dialog_height = 0
}
dialog.getModalDialog().css('margin',dialog_height+"px auto");
$("#map_box").css('height',h_height);
$("#map_box").css('width',h_width);
$("#mainMap").css('height',h_height);
$("#mainMap").css('width',h_width);
$("#map_img").attr('src',"/static/images/all.png");
op = "all"
}
$("#mainMap").html("")
getMap()
})
</script>