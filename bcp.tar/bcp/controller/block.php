<?

?>

<?head()?>

<div class="row">

<div class="all" id="all">
<div class="all-title-box">
</div>
<div id="block_info"></div>
<div class="clearfix"></div>
<div id="block_tx"></div>
<div class="clearfix mb100"></div>
</div>
<div id="block_url" class="hidden"><?=$args[2]?>?sign=4d26178d68aaea6e00240fe5d66cdec3</div>

</div>

<?foot()?>
<script src="/static/js/block.js"></script>
</body></html>