<?
$info = $rpc->getinfo();
print_r($info);
?>