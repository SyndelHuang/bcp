<?head()?>
<div class="row">

<div class="all" id="all">
<div class="all-title-box">
<div class="all-title">交易</div>
<div class="details"><a href="javascript:;" id="det">交易细节</a></div>
</div>
<div class="tx-info  tx-bgimg-btc " id="tx_info">
</div>
<div class="clearfix"></div>
<div class="addrs">
<div class="addrs-left" id="left">
</div>
<div class="addrs-img"><img src="/static/images/tx_jt.png?v=d35718e5b5b1e095fc3f700b5ccc78f9"></div>
<div class="addrs-right" id="right">
</div>
</div>
<div class="clearfix mb100"></div>
</div>
<div id="tx_url" class="hidden"><?=$args[2]?>?sign=52778354d3ed8e8e0af0be4c33d932e6</div>

</div>

<?foot()?>
<script src="/static/js/tx.js"></script>
</body></html>