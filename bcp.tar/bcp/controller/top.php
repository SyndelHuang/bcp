<?
//余额统计必须用缓存文件来做，不能在数据表的余额字段增加索引，否则频繁的余额更新操作（几乎对每个vin和vout的处理都会更新一次余额表的某条记录的balance字段）会很耗费资源
//每天按时统计一次并将前50条写入缓存
//可能需要统计所有地址的排行榜，那么就新增一个余额排行表top,由于每天只刷新一次，这个表可以放索引
?>


<?head()?>
<div class="row">

<div class="all">
<div class="all-title-box">
<div class="all-title">地址余额排行</div>
</div>
<div class="tx-info  tx-bgimg-btc " id="tx_info">
</div>
<div class="clearfix"></div>
<div class="table-responsive toptable">
<table class="table">
<thead class="top">
<tr>
<th class="td1">排行</th>
<th class="td2">地址</th>
<th class="td3">余额</th>
<th class="td4">最后一次交易时间</th>
<th class="td5">&nbsp;</th>
</tr>
</thead>
<tbody id="a_table"></tbody>
</table>
</div>
<div class="clearfix mb100"></div>
</div>

</div>

<?foot()?>
<script src="/static/js/top.js"></script>
</body></html>