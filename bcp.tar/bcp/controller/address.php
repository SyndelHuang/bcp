<?head()?>

<div class="row">

<div class="all" id="all">
<div class="all-title-box">
<div class="all-title" id="addr-title">地址</div>
</div>
<div class="tx-info addr-bgimg-btc min-h mb22" id="tx_info">
</div>
</div>
<div id="a_url" class="hidden"><?=$args[2]?>?sign=c611a0e60d9e8f990746a4c744d0476c</div>

</div>

<?foot()?>
<script src="/static/js/jquery.qrcode.min.js"></script>
<script src="/static/js/address.js"></script>
</body></html>