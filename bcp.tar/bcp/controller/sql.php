<?

  $link = @mysqli_connect("127.0.0.1","root","root","mychain");

  if (!$link) 
  {
      die ('Could not connect:' . @mysqli_error($link));
  }
  else echo "Mysql已正确配置";

  @mysqli_close($link);
 
?>
