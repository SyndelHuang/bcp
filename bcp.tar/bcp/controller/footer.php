</div>
<div class="container footer">
<div class="foot">© 2016 <span>qukuai.ybi.net</span> All rights reserved 
&nbsp;&nbsp; 
&nbsp;&nbsp;<span style="cursor:pointer" onclick="alert('维护人员QQ:276448114,承接区块浏览器制作');">维护人员</span> 
 </div>
</div>

<!--[if lt IE 9]>
<script src="/static/js/html5shiv.min.js?v=bc0679a1f805567fd478cbc0c845c075"></script>
<script src="/static/js/respond.min.js?v=44ccd9c8f8438737612f35923c12135c"></script>
<![endif]-->
<script src="/static/js/l10n.min.js"></script>
<script src="/static/js/language.js"></script>

<script src="/static/js/base.js"></script>
