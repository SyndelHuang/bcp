<?
//接受get数据并重定向到特定的URL
$keyword = trim( $_GET['search'] );
if( strlen($keyword)==34 ){
	//地址查询：
	header('location:address/'.$keyword);
}elseif( strlen($keyword)==64 ){
	//可能是区块hash也可能是交易hash，并且这个币的区块hash开头未必有数个0，比如高度20000的区块开头没有0，可能因为它是POS币
	$hash = $keyword;
	{//连接MYSQL
		define('AUTOUPDATE',false);
		include_once('lib/Mysql.php');
		Db::init($db_config);
	}
	$block = Db::getRow("SELECT hash FROM block WHERE hash='$hash'");
	//$block = $rpc->getblock($hash);//不可以用RPC，因查不到时会报错
	if($block){//那么这是区块哈希：
		header('location:block/'.$keyword);
	}else{//就只剩下交易这种可能了：
		header('location:tx/'.$keyword);
	}
}elseif( preg_match('/^[0-9]+$/',$keyword ) ){//这个elseif最好放到最后
	//是整数，证明是区块高度
	header('location:block/'.$keyword);
}//ok
?>
