<?
{//simple framework
	error_reporting(E_ALL ^ E_NOTICE);
	//路由
	function route($separator){
		$URI = $_SERVER['REQUEST_URI'];
		$URI = explode('?',$URI);
		$URI = $URI[0];//去掉$_SERVER['QUERY_STRING']
		$arr = explode($separator,$URI);
		$string = $arr[1];
		$arr = explode('/',$string);
		$controller = $arr[0];
		//if($controller !== 'test'){
		//	echo 'data refreshing';die;
		//}
		if(!$controller) $controller = 'index';
		$phpfile = "controller/$controller.php";//找到要执行的文件
		if( !file_exists($phpfile) ){
			echo '<meta charset="utf-8">';
			//die( 'file no exists:'.$phpfile );
			die("don't hack me ");
			//die("网址解析失败，<font color=red>$controller</font>不是一个合法的controller");
		}
		return $phpfile;
	}
	//视图
	function head(){
		include('controller/header.php');
	}
	function foot(){
		include('controller/footer.php');
	}
}

include_once('config/config.php');
{
	//只有api2.php需要连接MYSQL所以相关代码移动到那页了

}

{
	//需要php.ini allow_url_fopen = On
	include_once 'lib/jsonRPCClient.php';
	$rpc = new jsonRPCClient("http://$rpcuser:$rpcpass@127.0.0.1:".PORT_COIN.'/'); 
        /*
	try{//测试数据连接：
		$info = $rpc->getinfo();
                echo ("<meta charset='utf-8'>");
		echo json_encode($info);
        }catch(Exception $e){
		echo("<meta charset='utf-8'>无法连接到加密货币的RPC端口，可能它未启动<br>");
		echo $e->getmessage();
		die;
	}
        */
	

}
$args = explode('?',$_SERVER['REQUEST_URI']);
$args = explode('/',$args[0]);
include_once(route($separator));

?>
